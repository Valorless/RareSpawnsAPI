package valorless.rarespawns.builders.components;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.UseCooldownComponent;

import valorless.rarespawns.Main;
import valorless.valorlessutils.ValorlessUtils.Log;
import valorless.valorlessutils.config.Config;

/**
 * Represents a cooldown component that can be applied to an item.
 * This component defines the cooldown behavior when the item is used.
 * <p>
 * Links to Bukkit API:
 * <ul>
 *   <li>{@link org.bukkit.inventory.meta.components.UseCooldownComponent}</li>
 *   <li>{@link org.bukkit.NamespacedKey}</li>
 *   <li>{@link org.bukkit.inventory.ItemStack}</li>
 *   <li>{@link org.bukkit.inventory.meta.ItemMeta}</li>
 * </ul>
 */
public class Cooldown {
	
	/**
	 * The underlying Bukkit cooldown component.
	 * @see org.bukkit.inventory.meta.components.UseCooldownComponent
	 */
	UseCooldownComponent comp = null;
	
	/**
	 * Initializes the cooldown component based on the provided configuration.
	 * <p>
	 * Supported config keys:
	 * <ul>
	 *   <li>use-cooldown.cooldown</li>
	 *   <li>use-cooldown.group</li>
	 * </ul>
	 * @param config The configuration object containing cooldown settings.
	 * @see valorless.valorlessutils.config.Config
	 */
	public Cooldown(Config config) {
		// Create a dummy item to get a default UseCooldownComponent
		ItemStack dummy = new ItemStack(Material.GOAT_HORN);
		comp = dummy.getItemMeta().getUseCooldown();
		
		// Read config values
		float cooldown = config.HasKey("use-cooldown.cooldown") ? config.GetDouble("use-cooldown.cooldown").floatValue() : 1.0f;
		String groupKey = config.HasKey("use-cooldown.group") ? config.GetString("use-cooldown.group") : "rarespawns:cooldown";
		String namespace;
		String key;
		
		// Parse and validate groupKey as NamespacedKey
		try {
			String[] split = groupKey.split(":");
			namespace = split[0];
			key = split[1]; 
			if(split.length > 2) throw new Exception();
		}catch(Exception e) {
			Log.Error(Main.plugin, String.format("Invalid cooldown group in %s.", config.GetFile().getFile().getName()));
			return;
		}
		
		// Set cooldown properties
		comp.setCooldownSeconds(cooldown); // Cooldown duration in seconds
		comp.setCooldownGroup(new NamespacedKey(namespace, key)); // Cooldown group identifier
	}

	/**
	 * Applies the cooldown component to the given item stack.
	 * @param item The item stack to apply the component to.
	 * @see org.bukkit.inventory.ItemStack
	 * @see org.bukkit.inventory.meta.ItemMeta
	 */
	public void apply(ItemStack item) {
		ItemMeta meta = item.getItemMeta();
		meta.setUseCooldown(comp);
		item.setItemMeta(meta);
	}

}