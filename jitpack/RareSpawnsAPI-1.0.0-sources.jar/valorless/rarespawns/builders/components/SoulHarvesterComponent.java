package valorless.rarespawns.builders.components;

import java.util.ArrayList;
import java.util.List;

import valorless.rarespawns.datamodels.SoulHarvesterUpgrade;
import valorless.rarespawns.enums.SoulHarvesterGainType;

/**
 * Component that configures Soul Harvester behavior for an entity or item.
 * <p>
 * Tracks how many souls are collected per qualifying gain, the maximum number
 * of souls that can be stored, and any upgrades that modify this behavior.
 * </p>
 */
public class SoulHarvesterComponent {
	
	/**
	 * Number of souls gained per qualifying gain.
	 * Default: 1
	 */
	public Integer soulsPerGain = 1;
	
	/**
	 * Maximum number of souls that can be stored.
	 * Default: 10
	 */
	public Integer maxSouls = 10;
	
	/**
	 * Whether kills from spawner-generated entities count towards soul collection.
	 * Default: false
	 */
	public boolean spawners = false;
	
	/**
	 * List of world names where soul collection is enabled or disabled based on isBlacklist.
	 * Default: empty list
	 */
	public List<String> worlds = new ArrayList<>();
	
	/**
	 * Whether the worlds list is a blacklist (true) or whitelist (false).
	 * Default: false
	 */
	public boolean isBlacklist = false;
	
	/**
	 * The method by which souls are gained.
	 * Default: KILL
	 */
	public SoulHarvesterGainType gainType = SoulHarvesterGainType.KILL;
	
	/**
	 * Upgrades that modify the Soul Harvester's behavior.
	 * Typically populated from configuration or progression systems.
	 */
	public List<SoulHarvesterUpgrade> upgrades = new ArrayList<>();
	
	/**
	 * Creates a SoulHarvesterComponent with default values and an empty upgrade list.
	 */
	public SoulHarvesterComponent() {
	}
}