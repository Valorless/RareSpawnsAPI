package valorless.rarespawns.builders.components;

import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.consumable.ConsumeEffect;
import io.papermc.paper.datacomponent.item.consumable.ConsumeEffect.ApplyStatusEffects;
import io.papermc.paper.datacomponent.item.consumable.ItemUseAnimation;
import net.kyori.adventure.key.Key;
import org.bukkit.Registry;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import valorless.rarespawns.Main;
import valorless.rarespawns.datamodels.Sound;
import valorless.valorlessutils.config.Config;
import valorless.valorlessutils.logging.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Paper-specific consumable component that can be applied to an item.
 * This component defines the behavior when the item is consumed, utilizing Paper's API.
 * <p>
 * Links to Paper API:
 * <ul>
 *   <li>{@link io.papermc.paper.datacomponent.item.Consumable}</li>
 *   <li>{@link ItemUseAnimation}</li>
 *   <li>{@link ApplyStatusEffects}</li>
 * </ul>
 * Links to Bukkit API:
 * <ul>
 *   <li>{@link ItemStack}</li>
 *   <li>{@link PotionEffect}</li>
 *   <li>{@link PotionEffectType}</li>
 *   <li>{@link org.bukkit.Sound}</li>
 * </ul>
 * Links to config:
 * <ul>
 *   <li>{@link Config}</li>
 * </ul>
 */
public class Consumable {

	/**
	 * The underlying Paper Consumable component.
	 * @see io.papermc.paper.datacomponent.item.Consumable
	 */
	public final io.papermc.paper.datacomponent.item.Consumable comp;

	/**
	 * Initializes the Paper consumable component based on the provided configuration.
	 * Reads config keys and sets up the consumable's properties and effects.
	 * <p>
	 * Supported config keys:
	 * <ul>
	 *   <li>food.eat-speed</li>
	 *   <li>food.effects</li>
	 *   <li>food.animation</li>
	 *   <li>food.sound</li>
	 *   <li>food.particles</li>
	 * </ul>
	 * @param config The configuration object containing consumable settings.
	 * @see Config
	 */
	@SuppressWarnings("deprecation")
	public Consumable(Config config) {
		Log.debug(Main.plugin, "Paper Consumable: " + config.GetFile().getFile().getName());
		io.papermc.paper.datacomponent.item.Consumable.Builder consume = io.papermc.paper.datacomponent.item.Consumable.consumable();

		// Read config values
		Double speed = config.hasKey("food.eat-speed") ? config.getDouble("food.eat-speed") : null;
		List<String> effects = config.hasKey("food.effects") ? config.getStringList("food.effects") : null;
		ItemUseAnimation animation = config.hasKey("food.animation") ? ItemUseAnimation.valueOf(config.getString("food.animation")) : null;
		Sound sound = config.hasKey("food.sound") ? Sound.parse(config.getString("food.sound")) : null;
		Boolean particles = config.hasKey("food.particles") ? Boolean.valueOf(config.getString("food.particles")) : null;

		// Set eat speed if provided
		if(speed != null) consume.consumeSeconds(speed.floatValue());

		// Parse and add potion effects if provided
		if (effects != null) {
			for (String entry : effects) {
				String[] split = entry.split(":");
				PotionEffectType type = Registry.EFFECT.match(split[0].toLowerCase());
				int level = Integer.parseInt(split[1]);
				int duration = Integer.parseInt(split[2]);
				float chance = Float.parseFloat(split[3]);

				PotionEffect effect = new PotionEffect(type, duration, level - 1);
				List<PotionEffect> effs= new ArrayList<>();
				effs.add(effect);
				ApplyStatusEffects cEffect = ConsumeEffect.applyStatusEffects(effs, chance);
				consume.addEffect(cEffect);
			}
		}

		// Set use animation if provided
		if(animation != null) consume.animation(animation);
		// Set sound if provided
		if(sound != null) consume.sound(Key.key(sound.key.toLowerCase().replace("_", ".")));
		// Set particle effect if provided
		if(particles != null) consume.hasConsumeParticles(particles);

		comp = consume.build();
	}

	/**
	 * Retrieves the underlying Consumable component.
	 * @return The Consumable instance.
	 * @see io.papermc.paper.datacomponent.item.Consumable
	 */
	public io.papermc.paper.datacomponent.item.Consumable getComponent() {
		Log.info(Main.plugin, "got " + comp.toString());
		return comp;
	}

	/**
	 * Applies a Paper Consumable instance to an ItemStack reflectively.
	 * Skips if the server is Spigot or the consumable is null.
	 * <p>
	 * Uses reflection to access Paper's DataComponentTypes and set the consumable data.
	 * @param item The ItemStack to modify
	 * @see ItemStack
	 */
	public void apply(ItemStack item) {
		if (comp == null) return; // Nothing to apply
		ItemMeta meta = item.getItemMeta();
		item.setData(DataComponentTypes.CONSUMABLE, comp);
		item.setItemMeta(meta);
	}

}