package valorless.rarespawns.builders.components;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;

import valorless.rarespawns.Main;
import valorless.rarespawns.utils.SFX;
import valorless.valorlessutils.ValorlessUtils.Log;
import valorless.valorlessutils.config.Config;

/**
 * Represents an equippable component that can be applied to an item.
 * This component defines how the item can be equipped by entities.
 * <p>
 * Links to Bukkit API:
 * <ul>
 *   <li>{@link org.bukkit.inventory.meta.components.EquippableComponent}</li>
 *   <li>{@link org.bukkit.inventory.EquipmentSlot}</li>
 *   <li>{@link org.bukkit.NamespacedKey}</li>
 *   <li>{@link org.bukkit.entity.EntityType}</li>
 * </ul>
 */
public class Equippable {

	/**
	 * The underlying Bukkit equippable component.
	 * @see org.bukkit.inventory.meta.components.EquippableComponent
	 */
	EquippableComponent comp = null;

	/**
	 * Initializes the equippable component based on the provided configuration.
	 * <p>
	 * Supported config keys:
	 * <ul>
	 *   <li>equippable.slot</li>
	 *   <li>equippable.model</li>
	 *   <li>equippable.swappable</li>
	 *   <li>equippable.camera-overlay</li>
	 *   <li>equippable.damage-on-hurt</li>
	 *   <li>equippable.dispensable</li>
	 *   <li>equippable.equip-sound</li>
	 *   <li>equippable.allowed-entities</li>
	 * </ul>
	 * @param config The configuration object containing equippable settings.
	 * @see valorless.valorlessutils.config.Config
	 */
	public Equippable(Config config) {
		// Create a dummy item to get a default EquippableComponent
		ItemStack dummy = new ItemStack(Material.DIAMOND_CHESTPLATE);
		comp = dummy.getItemMeta().getEquippable();

		// Read config values
		EquipmentSlot slot = config.HasKey("equippable.slot") ? EquipmentSlot.valueOf(config.GetString("equippable.slot")) : null;
		String model = config.HasKey("equippable.model") ? config.GetString("equippable.model") : null;
		Boolean swappable = config.HasKey("equippable.swappable") ? config.GetBool("equippable.swappable") : null;
		String cameraOverlay = config.HasKey("equippable.camera-overlay") ? config.GetString("equippable.camera-overlay") : null;
		Boolean damage = config.HasKey("equippable.damage-on-hurt") ? config.GetBool("equippable.damage-on-hurt") : null;
		Boolean dispensable = config.HasKey("equippable.dispensable") ? config.GetBool("equippable.dispensable") : null;
		String sound = config.HasKey("equippable.equip-sound") ? config.GetString("equippable.equip-sound") : null;
		List<String> entities = config.HasKey("equippable.allowed-entities") ? config.GetStringList("equippable.allowed-entities") : null;

		// Set slot if provided
		comp.setSlot(slot);
		
		// Parse and set model namespace key
		String modelNamespace;
		String modelKey;
		NamespacedKey modelNK = null;
		try {
			String[] split = model.split(":");
			modelNamespace = split[0];
			modelKey = split[1]; 
			if(split.length > 2) throw new Exception();
			modelNK = new NamespacedKey(modelNamespace, modelKey);
		}catch(Exception e) {
			Log.Error(Main.plugin, String.format("Invalid equippable.model in %s.", config.GetFile().getFile().getName()));
		}

		if(modelNK != null) comp.setModel(modelNK);

		// Set swappable property
		if(swappable != null) comp.setSwappable(swappable);

		// Parse and set camera overlay namespace key
		String cameraNamespace;
		String cameraKey;
		NamespacedKey cameraNK = null;
		try {
			String[] split = model.split(":"); // Should this be cameraOverlay?
			cameraNamespace = split[0];
			cameraKey = split[1]; 
			if(split.length > 2) throw new Exception();
			cameraNK = new NamespacedKey(cameraNamespace, cameraKey);
		}catch(Exception e) {
			Log.Error(Main.plugin, String.format("Invalid equippable.camera-overlay in %s.", config.GetFile().getFile().getName()));
		}
		if(cameraOverlay != null) comp.setCameraOverlay(cameraNK);

		// Set damage on hurt property
		if(damage != null) comp.setDamageOnHurt(damage);
		// Set dispensable property
		if(dispensable != null) comp.setDispensable(dispensable);
		// Set equip sound
		if(sound != null) comp.setEquipSound(SFX.GetSound(sound));

		// Set allowed entities
		if(entities != null && !entities.isEmpty()) {
			List<EntityType> types = new ArrayList<>();
			for(String type : entities) {
				types.add(EntityType.valueOf(type));
			}
			comp.setAllowedEntities(types);
		}
	}

	/**
	 * Applies the equippable component to the given item stack.
	 * @param item The item stack to apply the component to.
	 * @see org.bukkit.inventory.ItemStack
	 * @see org.bukkit.inventory.meta.ItemMeta
	 */
	public void apply(ItemStack item) {
		ItemMeta meta = item.getItemMeta();
		meta.setEquippable(comp);
		item.setItemMeta(meta);
	}

}