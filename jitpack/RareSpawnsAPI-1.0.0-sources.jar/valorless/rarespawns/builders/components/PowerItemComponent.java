package valorless.rarespawns.builders.components;

import java.util.ArrayList;
import java.util.List;

import valorless.rarespawns.datamodels.Sound;
import valorless.rarespawns.enums.PowerItemType;

/**
 * Configuration component describing how a Power Item behaves.
 * <p>
 * Holds flags and parameters controlling where and how a power item can be
 * used (consumable behavior, allowed blocks/worlds, drop/ominous rules,
 * per-use delay, permission, and optional sound cues).
 * Unless stated otherwise, null means "use plugin defaults".
 */
public class PowerItemComponent {
	
	/** Power item category/type this configuration applies to. */
	private final PowerItemType type;
	/** Whether this item is consumed on use (per activation). Null = default. */
	private Boolean consumable = false;
	/** Allow-list of blocks this item can interact with. Null = plugin default. */
	private List<String> blocks = new ArrayList<>();
	/** Whether target blocks drop items when broken via this item. Null = default. */
	private Boolean drops;
	/** Whether the block must be in an "ominous" state for this item's effect to apply. Null = default. */
	private Boolean ominous = false;
	/** Per-use cooldown in milliseconds for trowel-like interactions. Null = default. (100ms) */
	private Integer trowelDelay = 100;
	/** Durability cost per use for trowel-like interactions. Null = default. */
	private Integer trowelDurabilityCost = 1;
	/** Allow-list of world names where this item can be used. Null/empty = as configured by plugin. */
	private List<String> worlds = new ArrayList<>();
	/** Permission node required to use this item. Null = no extra permission. */
	private String permission;
	/** Optional sound cue to play on activation; null disables sound. */
	private Sound sound;
	
	/**
	 * Creates a new component for the given power item type.
	 *
	 * @param type the power item category this configuration applies to
	 */
	public PowerItemComponent(PowerItemType type) {
		this.type = type;
	}

	/**
	 * Gets the power item type this component represents.
	 *
	 * @return the power item type
	 */
	public PowerItemType getType() {
		return type;
	}

	/**
	 * Indicates whether the item is consumed on use.
	 *
	 * @return true if consumed; false if not; null to use default
	 */
	public Boolean getConsumable() {
		return consumable;
	}

	/**
	 * Sets whether the item is consumed on use.
	 *
	 * @param consumable true to consume; false to keep; null to use default
	 */
	public void setConsumable(Boolean consumable) {
		this.consumable = consumable;
	}

	/**
	 * Gets the allow-list of blocks the item can interact with.
	 *
	 * @return string list of materials, or null to allow plugin default
	 */
	public List<String> getBlocks() {
		return blocks;
	}

	/**
	 * Sets the allow-list of blocks the item can interact with.
	 *
	 * @param blocks string list of materials; null for default behavior
	 */
	public void setBlocks(List<String> blocks) {
		this.blocks = blocks;
	}

	/**
	 * Whether broken blocks should drop items when using this item.
	 *
	 * @return true to drop; false to suppress; null to use default
	 */
	public Boolean getDrops() {
		return drops;
	}

	/**
	 * Sets whether broken blocks should drop items when using this item.
	 *
	 * @param drops true to drop; false to suppress; null to use default
	 */
	public void setDrops(Boolean drops) {
		this.drops = drops;
	}

	/**
	 * Whether an "ominous" state is required for breaking/interaction to work.
	 *
	 * @return true if required; false if not; null to use default
	 */
	public Boolean getOminous() {
		return ominous;
	}

	/**
	 * Sets whether an "ominous" state is required for breaking/interaction to work.
	 *
	 * @param ominous true if required; false if not; null to use default
	 */
	public void setOminous(Boolean ominous) {
		this.ominous = ominous;
	}

	/**
	 * Gets the delay between uses (in milliseconds) for trowel interactions.
	 *
	 * @return delay in milliseconds; null to use default
	 */
	public Integer getTrowelDelay() {
		return trowelDelay;
	}

	/**
	 * Sets the delay between uses (in milliseconds) for trowel interactions.
	 *
	 * @param trowelDelay delay in milliseconds; null for default
	 */
	public void setTrowelDelay(Integer trowelDelay) {
		this.trowelDelay = trowelDelay;
	}

	/**
	 * Gets the durability cost per use for trowel interactions.
	 *
	 * @return durability cost; null to use default
	 */
	public Integer getTrowelDurabilityCost() {
		return trowelDurabilityCost;
	}

	/**
	 * Sets the durability cost per use for trowel interactions.
	 *
	 * @param trowelDurabilityCost durability cost; null for default
	 */
	public void setTrowelDurabilityCost(Integer trowelDurabilityCost) {
		this.trowelDurabilityCost = trowelDurabilityCost;
	}

	/**
	 * Gets the allow-list of worlds where the item can be used.
	 *
	 * @return list of world names; null or empty may mean allowed everywhere
	 */
	public List<String> getWorlds() {
		return worlds;
	}

	/**
	 * Sets the allow-list of worlds where the item can be used.
	 *
	 * @param worlds world names; null/empty to allow in all worlds (unless configured otherwise)
	 */
	public void setWorlds(List<String> worlds) {
		this.worlds = worlds;
	}

	/**
	 * Gets the permission node required to use the item.
	 *
	 * @return permission string; null if no permission required
	 */
	public String getPermission() {
		return permission;
	}

	/**
	 * Sets the permission node required to use the item.
	 *
	 * @param permission permission string; null if no permission required
	 */
	public void setPermission(String permission) {
		this.permission = permission;
	}

	/**
	 * Gets the optional sound to play when this power item is activated.
	 *
	 * @return the configured sound, or null if none
	 */
	public Sound getSound() {
		return sound;
	}

	/**
	 * Sets the activation sound from a compact string definition.
	 * <p>
	 * Expected formats follow {@link Sound#parse(String)} semantics, for example:
	 * "minecraft:entity.player.levelup:1.0:1.0" or "ENTITY_PLAYER_LEVELUP:0.8:1.2".
	 * Passing null clears the sound.
	 * </p>
	 *
	 * @param sound the sound definition string; null to disable
	 */
	public void setSound(String sound) {
		this.sound = Sound.parse(sound);
	}

	/**
	 * Sets the activation sound.
	 * <p>
	 * Passing null clears the sound.
	 * </p>
	 *
	 * @param sound the sound; null to disable
	 */
	public void setSound(Sound sound) {
		this.sound = sound;
	}
	
}