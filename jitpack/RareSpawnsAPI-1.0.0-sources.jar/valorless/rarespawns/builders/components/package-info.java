/**
 * Item builder components (consumable, cooldown, equippable, power item, etc.).
 * These augment ItemBuilder with feature-specific configuration.
 */
package valorless.rarespawns.builders.components;