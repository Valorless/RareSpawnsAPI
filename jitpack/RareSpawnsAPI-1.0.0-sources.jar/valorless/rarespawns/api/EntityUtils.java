package valorless.rarespawns.api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.BoundingBox;

import valorless.rarespawns.utils.Extra;
import valorless.rarespawns.world.SpawnUtils;

/**
 * Utility class that provides common helper methods for interacting with entities.
 * Includes functions for checking proximity, health percentage, exposure to sunlight,
 * calculating entity bounding box centers, and generating safe circular spawn locations
 * around a given origin.
 */
public class EntityUtils {

    static Random random = new Random();

    /**
     * Get a list of players within a specific radius around a living entity.
     *
     * @param entity The entity around which to search for players.
     * @param radius The radius within which to search for players.
     * @return A list of players within the specified radius.
     */
    public static List<Player> getPlayersInRadius(LivingEntity entity, double radius) {
        List<Player> playersInRange = new ArrayList<>();

        // Get the world of the entity
        World world = entity.getWorld();

        // Get the location of the entity
        Location entityLocation = entity.getLocation();

        // Iterate through all players in the same world
        for (Player player : world.getPlayers()) {
            // Check if the player is within the given radius of the entity
            if (player.getLocation().distance(entityLocation) <= radius) {
                playersInRange.add(player);
            }
        }

        return playersInRange;
    }

    /**
     * Calculate the current health percentage of a living entity.
     *
     * @param entity The entity whose health percentage is to be calculated.
     * @return The health percentage (0-100) of the entity.
     */
    @SuppressWarnings("deprecation")
    public static double getHealthPercentage(LivingEntity entity) {
        double maxHealth = 1;
        try {
            // Try using the standard MAX_HEALTH attribute
            maxHealth = entity.getAttribute(Attribute.valueOf("MAX_HEALTH")).getValue();
        } catch (Exception e) {
            // Fallback for older versions that may use GENERIC_MAX_HEALTH
            maxHealth = entity.getAttribute(Attribute.valueOf("GENERIC_MAX_HEALTH")).getValue();
        }

        double currentHealth = entity.getHealth();

        // Return the entity's health percentage relative to its maximum
        return (currentHealth / maxHealth) * 100;
    }

    /**
     * Check if an entity is exposed to direct sunlight.
     * <p>
     * This checks if the entity's current Y position is greater than or equal to
     * the highest block at its X and Z coordinates.
     * </p>
     *
     * @param entity The entity to check.
     * @return {@code true} if the entity is exposed to sunlight, {@code false} otherwise.
     */
    public static boolean isExposedToSunlight(Entity entity) {
        // Get the world of the entity
        World world = entity.getWorld();
        int x = entity.getLocation().getBlockX();
        int z = entity.getLocation().getBlockZ();

        // Get the highest block at the entity's X and Z coordinates
        Block highestBlock = world.getHighestBlockAt(x, z);

        // Get the Y coordinate of the highest block
        int highestY = highestBlock.getY();

        // Entity is exposed if it is above or at the highest block Y level
        if (entity.getLocation().getBlockY() >= highestY) {
            return true; // Exposed to sunlight
        } else {
            return false; // Covered by blocks above
        }
    }

    /**
     * Get the center location of an entity's bounding box.
     * <p>
     * This method calculates the midpoint of the entity's bounding box in all three dimensions.
     * Useful for effects or precise positioning relative to the entity.
     * </p>
     *
     * @param entity The entity whose center location is to be calculated.
     * @return The {@link Location} representing the center of the entity's bounding box.
     */
    public static Location getEntityCenter(Entity entity) {
        // Retrieve the entity's bounding box
        BoundingBox box = entity.getBoundingBox();

        // Calculate the midpoint coordinates of the bounding box
        return new Location(
                entity.getWorld(),
                (box.getMinX() + box.getMaxX()) / 2, // Center X
                (box.getMinY() + box.getMaxY()) / 2, // Center Y
                (box.getMinZ() + box.getMaxZ()) / 2  // Center Z
        );
    }

    /**
     * Generates safe spawn locations arranged in a circle around a given origin location.
     * Ensures each spawn point is not inside a solid block; otherwise, falls back to the origin.
     *
     * @param location The center/origin location to spawn around.
     * @param amount Number of spawn points to generate.
     * @param radius The radius of the circle.
     * @return List of safe spawn locations.
     */
    public static List<Location> generateSafeCircularSpawnLocations(Location location, int amount, double radius) {
        List<Location> spawnPoints = new ArrayList<>();
        // Calculate the angle between each point in radians
        double angleIncrement = (2 * Math.PI) / amount;
        // Loop to calculate each spawn point
        for (int i = 0; i < amount; i++) {
            // Calculate the angle for this point
            double angle = i * angleIncrement;
            // Calculate the X and Z coordinates using cosine and sine
            double x = location.getX() + radius * Math.cos(angle);
            double z = location.getZ() + radius * Math.sin(angle);
            double y = location.getY();  // Keep the same Y level as the origin
            // Create the spawn point as a Location
            Location spawnLocation = new Location(location.getWorld(), x, y, z);
            // Check if the spawn point is inside a solid block
            if (!isLocationSafe(spawnLocation)) {
                // If the spawn point isn't safe, use the origin location
                spawnLocation = location;
            }
            spawnPoints.add(spawnLocation);
        }
        return spawnPoints;
    }

    /**
     * Checks if the location is safe (not inside a solid block).
     *
     * @param location The location to check.
     * @return True if the location is safe, false otherwise.
     */
    public static boolean isLocationSafe(Location location) {
        Block block = location.getBlock();
        // Check if the block is not solid (air or passable blocks are safe)
        return !block.getType().isSolid();
    }

    /**
     * Formats a {@link Location} object into a readable string containing the world name and coordinates.<br>
     * Example output: <code>world (100.00, 64.00, 200.00)</code>
     *
     * @param loc the location to format
     * @return a formatted string in the form <code>"world (x, y, z)"</code>, with coordinates rounded to two decimals
     */
    public static String formatLocation(Location loc) {
        return String.format("%s (%.2f, %.2f, %.2f)",
                loc.getWorld().getName(),
                loc.getX(), loc.getY(), loc.getZ());
    }

    /**
     * Formats a {@link Location} object into a string based on the given format.
     * <p>
     * The format string can include the following placeholders:
     * <ul>
     *   <li><code>%w</code> - Replaced with the world's name</li>
     *   <li><code>%x</code> - Replaced with the X coordinate</li>
     *   <li><code>%y</code> - Replaced with the Y coordinate</li>
     *   <li><code>%z</code> - Replaced with the Z coordinate</li>
     * </ul>
     * Example usage: <code>"%w - %x %y %z"</code> → <code>world - 100.0 64.0 200.0</code>
     *
     * @param loc    the location to format
     * @param format the format string containing placeholders
     * @return a string with placeholders replaced by location values
     */
    public static String formatLocation(Location loc, String format) {
        return format.replace("%w", loc.getWorld().getName())
                .replace("%x", Extra.ToString(loc.getX()))
                .replace("%y", Extra.ToString(loc.getY()))
                .replace("%z", Extra.ToString(loc.getZ()));
    }

    /**
     * Returns the weapon attack damage for a {@link Mob} by inspecting the attribute
     * modifiers on its main-hand {@link ItemStack}.
     * <p>
     * Looks up Attribute.ATTACK_DAMAGE and, for version compatibility, falls back to
     * Attribute.GENERIC_ATTACK_DAMAGE. If the item has multiple matching modifiers, the
     * first one encountered is used. If the mob holds no item or the item has no relevant
     * modifiers, this method returns {@code 3.0}.
     * </p>
     * <p>
     * Note: This reads only the item's attribute modifiers; it does not combine with the
     * mob's base attributes, enchantments, or effects.
     * </p>
     *
     * @param mob the mob whose main-hand weapon is inspected
     * @return the attack damage value from the weapon's attribute modifiers, or 3.0 if unavailable
     */
    @SuppressWarnings("deprecation")
    public static double getDamage(Mob mob) {
        // Read the main-hand item and check for attribute modifiers on the item meta
        ItemStack weapon = mob.getEquipment().getItemInMainHand();
        if (weapon != null && weapon.hasItemMeta() && weapon.getItemMeta().hasAttributeModifiers()) {
            Collection<AttributeModifier> modifiers = null;

            try {
                // Prefer modern namespace
                modifiers = weapon.getItemMeta().getAttributeModifiers(Attribute.valueOf("ATTACK_DAMAGE"));
            } catch (Exception e) {
                try {
                    // Fallback for older versions
                    modifiers = weapon.getItemMeta().getAttributeModifiers(Attribute.valueOf("GENERIC_ATTACK_DAMAGE"));
                } catch (Exception ignored) {}
            }

            if (modifiers != null && !modifiers.isEmpty()) {
                // Use the first available modifier amount
                return modifiers.iterator().next().getAmount();
            }
        }
        // Default when no suitable modifier is present
        return 3.0;
    }

    /**
     * Returns the weapon attack speed for a {@link Mob} by inspecting the attribute
     * modifiers on its main-hand {@link ItemStack}.
     * <p>
     * Looks up Attribute.ATTACK_SPEED and, for version compatibility, falls back to
     * Attribute.GENERIC_ATTACK_SPEED. If multiple matching modifiers exist, the first
     * one encountered is used. If absent, this method returns {@code 1.0}.
     * </p>
     * <p>
     * Note: Only item attribute modifiers are considered; this does not account for the
     * mob's base attributes or temporary effects.
     * </p>
     *
     * @param mob the mob whose main-hand weapon is inspected
     * @return the attack speed value from the weapon's attribute modifiers, or 1.0 if unavailable
     */
    @SuppressWarnings("deprecation")
    public static double getAttackSpeed(Mob mob) {
        // Read the main-hand item and check for attribute modifiers on the item meta
        ItemStack weapon = mob.getEquipment().getItemInMainHand();
        if (weapon != null && weapon.hasItemMeta() && weapon.getItemMeta().hasAttributeModifiers()) {
            Collection<AttributeModifier> modifiers = null;

            try {
                // Prefer modern namespace
                modifiers = weapon.getItemMeta().getAttributeModifiers(Attribute.valueOf("ATTACK_SPEED"));
            } catch (Exception e) {
                try {
                    // Fallback for older versions
                    modifiers = weapon.getItemMeta().getAttributeModifiers(Attribute.valueOf("GENERIC_ATTACK_SPEED"));
                } catch (Exception ignored) {}
            }

            if (modifiers != null && !modifiers.isEmpty()) {
                // Use the first available modifier amount
                return modifiers.iterator().next().getAmount();
            }
        }
        // Default when no suitable modifier is present
        return 1.0;
    }

    /**
     * Finds the nearest player to the given rare entity.
     * @param entity The rare entity to check from.
     * @return The nearest Player, or null if none found.
     */
    public static Player getNearestPlayer(LivingEntity entity) {
        Location eLoc = entity.getLocation();
        Player closest = null;
        double closestSq = Double.MAX_VALUE;
        final double maxDist = 300.0;
        final double maxDistSq = maxDist * maxDist;

        for (Player player : entity.getWorld().getPlayers()) {
            double distSq = player.getLocation().distanceSquared(eLoc);
            if (distSq > maxDistSq) continue;

            if (distSq < closestSq) {
                closestSq = distSq;
                closest = player;
            }
        }
        return closest;
    }

    /**
     * Gets the distance to the nearest player from the given rare entity.
     * @param entity The rare entity to check from.
     * @return The distance to the nearest player as an integer, or Integer.MAX_VALUE if none found.
     */
    public static Double getNearestPlayerDistance(LivingEntity entity) {
        if(entity == null) return 9999.9;
        Location eLoc = entity.getLocation();
        double closestSq = Double.MAX_VALUE;
        final double maxDistSq = 300.0 * 300.0;

        for (Player p : entity.getWorld().getPlayers()) {
            if (p.getUniqueId().equals(entity.getUniqueId())) continue;
            double distSq = p.getLocation().distanceSquared(eLoc);
            if (distSq > maxDistSq) continue;
            if (distSq < closestSq) closestSq = distSq;
        }
        if (closestSq == Double.MAX_VALUE) return 9999.9;
        return Math.sqrt(closestSq);
    }

    /**
     * Gets the block directly below the specified location.
     *
     * @param location The location to check.
     * @return The block directly below the given location.
     */
    public static Block getGroundBlockBelow(Location location) {
        return location.getWorld().getBlockAt(location.getBlockX(), location.getBlockY() - 1, location.getBlockZ());
    }

    /**
     * Gets a random valid spawn location between minRange and maxRange blocks away from the origin.
     * Intended for pack spawning — finding nearby spots around an existing spawn.
     * Tries up to 10 candidate locations before giving up.
     *
     * @param origin    The original spawn location to search around.
     * @param minRange  The minimum horizontal distance from the origin.
     * @param maxRange  The maximum horizontal distance from the origin.
     * @return A valid nearby spawn Location, or null if none found within 10 attempts.
     */
    public static Location getNearbySpawnLocation(Location origin, double minRange, double maxRange) {
        World world = origin.getWorld();

        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = random.nextDouble() * 2 * Math.PI;
            double distance = minRange + random.nextDouble() * (maxRange - minRange);

            double x = origin.getX() + distance * Math.cos(angle);
            double z = origin.getZ() + distance * Math.sin(angle);

            int searchY = (int) origin.getY() + 4;
            int minY = (int) origin.getY() - 4;

            for (int y = searchY; y > minY; y--) {
                // Block lookups still need int coords, so we use blockX/blockZ
                Block block = world.getBlockAt((int) x, y, (int) z);
                Block below = world.getBlockAt((int) x, y - 1, (int) z);

                if (!block.isPassable()) continue;
                if (!below.getType().isSolid()) continue;
                if (SpawnUtils.isTreeOrStructure(below.getType())) continue;

                // Location uses the full double x/z for sub-block precision
                return new Location(world, x, y, z);
            }
        }

        return null;
    }
}