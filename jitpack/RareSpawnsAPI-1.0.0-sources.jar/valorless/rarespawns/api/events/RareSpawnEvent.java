package valorless.rarespawns.api.events;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import valorless.rarespawns.api.enums.SpawnCause;
import valorless.rarespawns.datamodels.EntityData;

/**
 * Event fired when a rare entity is spawned by RareSpawns.
 * <p>
 * Carries the spawn's unique id, the spawned {@link LivingEntity}, its associated
 * {@link EntityData} definition, and the {@link Location} where it appeared.
 * This event is posted synchronously on the server thread.
 * </p>
 * <p>
 * Spawn origin: {@link SpawnCause} indicates where the spawn originated.
 * <ul>
 *   <li>{@link SpawnCause#INTERNAL} — spawned by RareSpawns' own systems (built-in logic,
 *   schedules, config rules, or internal commands).</li>
 *   <li>{@link SpawnCause#EXTERNAL} — spawned through the RareSpawns public API (typically
 *   initiated by another plugin via an API call).</li>
 *   <li>{@link SpawnCause#NULL} — unknown/unspecified.</li>
 * </ul>
 * </p>
 * <p>
 * Listen to this event to implement custom reactions (e.g., announcements,
 * additional effects, logging, or integrations).
 * </p>
 */
public class RareSpawnEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    
    private final String id;
    private final LivingEntity rare;
    private final EntityData data;
    private final Location location;
    private final SpawnCause cause;
    protected boolean called = false;
    
    /**
     * Creates a new RareSpawnEvent.
     *
     * @param id        Unique id of the rare definition that spawned.
     * @param data      The configuration/data backing the spawned rare.
     * @param rare      The spawned rare entity instance.
     * @param location  The world location where the rare spawned.
     * @param cause     The origin of the spawn, see {@link SpawnCause} for semantics.
     */
    public RareSpawnEvent(String id, EntityData data, LivingEntity rare, Location location, SpawnCause cause) {
        this.id = id;
        this.rare = rare;
        this.data = data;
        this.location = location;
		this.cause = cause;
    }
    
    /**
     * Fires this RareSpawnEvent via the Bukkit event bus.
     * <p>
     * Calls Bukkit.getPluginManager().callEvent(this) synchronously on the main server thread,
     * notifying all registered listeners. This event is not cancellable.
     * </p>
     * <p>
     * This method is single-use. If invoked more than once, it throws an {@link IllegalStateException}.
     * After a successful dispatch, the internal {@code called} flag is set to {@code true} to prevent re-dispatch.
     * </p>
     * <p>
     * Only call from the server thread. From asynchronous contexts, schedule a synchronous task first.
     * </p>
     *
     * @throws IllegalStateException if the event has already been dispatched
     */
    public void call() {
        // Publish the event to Bukkit's event bus (synchronous). Ensure single dispatch.
    	if (called) {
			throw new IllegalStateException("RareSpawnEvent has already been called.");
		}
		Bukkit.getPluginManager().callEvent(this);
		called = true;
	}

    /**
     * Gets the unique id of the rare definition that spawned.
     *
     * @return rare id
     */
    public String getId() {
        return id;
    }

    /**
     * Gets the spawned rare entity instance.
     *
     * @return the rare {@link LivingEntity}
     */
    public LivingEntity getRareEntity() {
        return rare;
    }

    /**
     * Gets the data backing the spawned rare.
     *
     * @return {@link EntityData} associated with this spawn
     */
    public EntityData getEntityData() {
        return data;
    }

    /**
     * Gets the location where the rare spawned.
     *
     * @return spawn {@link Location}
     */
    public Location getLocation() {
        return location;
    }

    /**
     * Gets the origin/cause of this spawn.
     * <p>
     * INTERNAL = spawned by RareSpawns' internal systems; EXTERNAL = spawned via the
     * public API by an external caller; NULL = unknown.
     * </p>
     *
     * @return {@link SpawnCause} describing where the spawn originated
     */
    public SpawnCause getCause() {
		return cause;
	}

	/**
     * Required boilerplate for Bukkit custom events.
     */
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    /**
     * Required boilerplate for Bukkit custom events.
     *
     * @return static handler list
     */
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

}