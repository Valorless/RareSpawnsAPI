package valorless.rarespawns.api.events;

import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;

import valorless.rarespawns.datamodels.EntityData;

/**
 * Event fired when a rare entity dies in RareSpawns.
 * <p>
 * Carries the rare's unique id, its {@link EntityData} definition, the {@link Location}
 * where it died, the killing {@link Entity} (may be {@code null}), the list of
 * {@link ItemStack} drops attributed to the death, and a flag indicating whether
 * the death was triggered by a command (e.g., admin) rather than standard gameplay.
 * This event is posted synchronously on the server thread.
 * </p>
 * <p>
 * Listen to this event to implement custom reactions (e.g., announcements,
 * custom loot logic, logging, or integrations).
 * </p>
 */
public class RareDeathEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    
    private final String id;
    private final EntityData data;
    private final Location location;
    private final Player killer;
    private final List<ItemStack> drops;
    private final boolean byCommand;
    protected boolean called = false;
    
    /**
     * Creates a new RareDeathEvent.
     *
     * @param id        Unique id of the rare definition that died.
     * @param data      The configuration/data associated with the rare.
     * @param location  The world location where the rare died.
     * @param killer    The player responsible for the kill; may be {@code null}.
     * @param drops     The item drops associated with this death.
     * @param byCommand {@code true} if the death was caused via a command; {@code false} otherwise.
     */
    public RareDeathEvent(String id, EntityData data, Location location, Player killer, List<ItemStack> drops, boolean byCommand) {
        this.id = id;
        this.data = data;
        this.location = location;
        this.killer = killer;
        this.drops = drops;
		this.byCommand = byCommand;
    }
    
    /**
     * Fires this RareDeathEvent via the Bukkit event bus.
     * <p>
     * Calls Bukkit.getPluginManager().callEvent(this) synchronously on the main server thread,
     * notifying all registered listeners. This event is not cancellable.
     * </p>
     * <p>
     * This method is single-use. If invoked more than once, it throws an {@link IllegalStateException}.
     * After a successful dispatch, the internal {@code called} flag is set to {@code true} to prevent re-dispatch.
     * </p>
     * <p>
     * Only call from the server thread. From asynchronous contexts, schedule a synchronous task first.
     * </p>
     *
     * @throws IllegalStateException if the event has already been dispatched
     */
    public void call() {
        // Publish the event to Bukkit's event bus (synchronous). Ensure single dispatch.
    	if (called) {
			throw new IllegalStateException("RareDeathEvent has already been called.");
		}
		Bukkit.getPluginManager().callEvent(this);
		called = true;
	}

    /**
     * Gets the unique id of the rare definition that died.
     *
     * @return rare id
     */
    public String getId() {
        return id;
    }

    /**
     * Gets the data backing the rare that died.
     *
     * @return {@link EntityData} associated with this death
     */
    public EntityData getEntityData() {
        return data;
    }

    /**
     * Gets the location where the rare died.
     *
     * @return death {@link Location}
     */
    public Location getLocation() {
        return location;
    }

    /**
     * Gets the player responsible for the kill.
     *
     * @return killer {@link Player}, or {@code null} if not applicable
     */
    public Player getKiller() {
        return killer;
    }

    /**
     * Gets the item drops associated with this death.
     *
     * @return list of {@link ItemStack} drops
     */
    public List<ItemStack> getDrops() {
        return drops;
    }

    /**
     * Indicates whether the death was triggered by a command.
     * <p>
     * Useful to distinguish admin-initiated removals from natural or combat deaths.
     * </p>
     *
     * @return {@code true} if caused via a command; {@code false} otherwise
     */
    public boolean isByCommand() {
		return byCommand;
	}

	/**
     * Required boilerplate for Bukkit custom events.
     */
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    /**
     * Required boilerplate for Bukkit custom events.
     *
     * @return static handler list
     */
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

}