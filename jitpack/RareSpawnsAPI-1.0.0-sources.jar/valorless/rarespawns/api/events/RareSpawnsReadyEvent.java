package valorless.rarespawns.api.events;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Event fired when RareSpawns has finished loading all rare entity definitions
 * and is ready for gameplay.
 * Used to signal to other plugins that RareSpawns is fully initialized.
 * <p>
 * This event is posted synchronously on the server thread.
 * </p>
 * <p>
 * Listen to this event to perform actions that depend on RareSpawns being fully initialized,
 * such as spawning rares or integrating with other plugins.
 * </p>
 */
public class RareSpawnsReadyEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    
    protected boolean called = false;
    
    /**
	 * Creates a new RareSpawnsReadyEvent.
	 */
    public RareSpawnsReadyEvent() {}
    
    /**
	 * Calls the RareSpawnsReadyEvent on Bukkit's event bus.
	 * Ensures the event is only called once.
	 */
    public void call() {
        // Publish the event to Bukkit's event bus (synchronous). Ensure single dispatch.
    	if (called) {
			throw new IllegalStateException("RareSpawnsReadyEvent has already been called.");
		}
		Bukkit.getPluginManager().callEvent(this);
		called = true;
	}

	/**
     * Required boilerplate for Bukkit custom events.
     */
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    /**
     * Required boilerplate for Bukkit custom events.
     *
     * @return static handler list
     */
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

}