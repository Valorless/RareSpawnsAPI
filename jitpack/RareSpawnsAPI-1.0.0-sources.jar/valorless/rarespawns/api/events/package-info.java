/**
 * Bukkit events fired by the RareSpawns API.
 * Listen here to react to rare entity and item lifecycle hooks.
 */
package valorless.rarespawns.api.events;