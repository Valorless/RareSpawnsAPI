package valorless.rarespawns.api.events;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import valorless.rarespawns.datamodels.EntityData;

/**
 * Event fired when a rare entity is updated in RareSpawns.
 * <p>
 * Carries the rare's unique id, the updated {@link LivingEntity}, its associated
 * {@link EntityData} definition, and the {@link Location} where it is located.
 * This event is posted synchronously on the server thread.
 * </p>
 * <p>
 * What counts as an update: this event is fired both when a rare is first
 * registered/tracked by RareSpawns (see {@link #isNew()}) and when RareSpawns
 * refreshes tracked rares in response to world/player events handled by
 * {@link valorless.rarespawns.events.UpdateEvent UpdateEvent}:
 * </p>
 * <ul>
 *   <li>Chunk loads ({@code ChunkLoadEvent}) — rares in the loaded chunk are refreshed.</li>
 *   <li>Player joins ({@code PlayerJoinEvent}) — after a short delay, nearby rares are refreshed.</li>
 *   <li>Player teleports ({@code PlayerTeleportEvent}) — after a short delay, nearby rares are refreshed.</li>
 * </ul>
 * <p>
 * Listen to this event to implement custom reactions (e.g., announcements,
 * additional effects, logging, or integrations).
 * </p>
 */
public class RareUpdateEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    
    private final String id;
    private final LivingEntity rare;
    private final EntityData data;
    private final Location location;
    private final boolean New;
    protected boolean called = false;
    
    /**
     * Creates a new RareUpdateEvent.
     *
     * @param id        Unique id of the rare definition that was updated.
     * @param data      The configuration/data backing the updated rare.
     * @param rare      The updated rare entity instance.
     * @param location  The world location of the rare at the time of this update.
     * @param New       {@code true} if this is the initial registration of the rare;
     *                  {@code false} for a subsequent refresh/update.
     */
    public RareUpdateEvent(String id, EntityData data, LivingEntity rare, Location location, boolean New) {
        this.id = id;
        this.rare = rare;
        this.data = data;
        this.location = location;
        this.New = New;
    }
    
    /**
     * Fires this RareUpdateEvent via the Bukkit event bus.
     * <p>
     * Calls Bukkit.getPluginManager().callEvent(this) synchronously on the main server thread,
     * notifying all registered listeners. This event is not cancellable.
     * </p>
     * <p>
     * This method is single-use. If invoked more than once, it throws an {@link IllegalStateException}.
     * After a successful dispatch, the internal {@code called} flag is set to {@code true} to prevent re-dispatch.
     * </p>
     * <p>
     * Only call from the server thread. From asynchronous contexts, schedule a synchronous task first.
     * </p>
     *
     * @throws IllegalStateException if the event has already been dispatched
     */
    public void call() {
        // Publish the event to Bukkit's event bus (synchronous). Ensure single dispatch.
    	if (called) {
			throw new IllegalStateException("RareUpdateEvent has already been called.");
		}
		Bukkit.getPluginManager().callEvent(this);
		called = true;
	}

    /**
     * Gets the unique id of the rare definition that was updated.
     *
     * @return rare id
     */
    public String getId() {
        return id;
    }

    /**
     * Gets the updated rare entity instance.
     *
     * @return the rare {@link LivingEntity}
     */
    public LivingEntity getRareEntity() {
        return rare;
    }

    /**
     * Gets the data backing the updated rare.
     *
     * @return {@link EntityData} associated with this update
     */
    public EntityData getEntityData() {
        return data;
    }

    /**
     * Gets the location of the rare at the time of this update.
     *
     * @return {@link Location}
     */
    public Location getLocation() {
        return location;
    }

    /**
     * Returns true if this rare entity is newly spawned, false if it is an update to an existing entity.
     * 
     * @return true if newly spawned, false if updated
     */
    public boolean isNew() {
		return New;
	}

	/**
     * Required boilerplate for Bukkit custom events.
     */
    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    /**
     * Required boilerplate for Bukkit custom events.
     *
     * @return static handler list
     */
    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

}