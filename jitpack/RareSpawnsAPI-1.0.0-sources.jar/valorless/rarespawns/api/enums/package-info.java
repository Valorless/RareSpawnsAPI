/**
 * Public API enums used by RareSpawns and dependent plugins.
 */
package valorless.rarespawns.api.enums;