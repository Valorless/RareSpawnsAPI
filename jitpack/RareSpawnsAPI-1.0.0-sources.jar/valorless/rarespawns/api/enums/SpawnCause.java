package valorless.rarespawns.api.enums;

/**
 * Describes where a rare entity spawn originated.
 * <p>
 * INTERNAL = spawned by RareSpawns' own systems (built‑in logic, schedules, config rules, or internal commands).
 * EXTERNAL = spawned through the RareSpawns public API (i.e., a call into the API triggered the spawn), typically by another plugin.
 * Use NULL when the origin cannot be determined.
 * </p>
 */
public enum SpawnCause {
	/**
	 * Unspecified or unknown cause. Use when the origin cannot be determined.
	 */
	NULL,
	/**
	 * Spawned by this plugin (RareSpawns) via its internal mechanisms
	 * such as natural/automated spawns, scheduled tasks, configuration rules,
	 * or internal command handlers.
	 */
	INTERNAL,
	/**
	 * Spawned through the RareSpawns public API.
	 * <p>
	 * This indicates an API call initiated the spawn, usually from another plugin
	 * integrating with RareSpawns. Prefer this over INTERNAL whenever the spawn
	 * path goes through API entry points.
	 * </p>
	 */
	EXTERNAL
}