package valorless.rarespawns.api;

import java.util.List;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import valorless.rarespawns.Main;
import valorless.rarespawns.RareSpawns;
import valorless.rarespawns.builders.AbilityCreator;
import valorless.rarespawns.builders.EntityCreator;
import valorless.rarespawns.builders.ItemBuilder;
import valorless.rarespawns.builders.ItemCache;
import valorless.rarespawns.compilers.SoulPowerCompiler;
import valorless.rarespawns.datamodels.AbilityInfo;
import valorless.rarespawns.datamodels.EntityData;
import valorless.rarespawns.datamodels.ItemData;
import valorless.rarespawns.datamodels.SoulPowerInfo;

/**
 * Static entry point for external integrations with RareSpawns.
 * <p>
 * Provides helpers to check/query rare entities and items, list available
 * identifiers, and spawn rares via the public API. Spawns triggered from
 * this API are considered {@code EXTERNAL} per {@link valorless.rarespawns.api.enums.SpawnCause}.
 * </p>
 * <p>
 * Threading: Call these methods on the main server thread unless otherwise noted.
 * </p>
 */
public class RareSpawnsAPI {

	/**
	 * Gets the current plugin instance of RareSpawns.
	 *
	 * @return the active {@link JavaPlugin} instance
	 */
	public static JavaPlugin getInstance() {
		return Main.plugin;
	}

	/**
	 * Checks whether RareSpawns is fully initialized and ready for API use.
	 *
	 * @return {@code true} if RareSpawns is ready, {@code false} otherwise
	 */
	public static boolean isReady() {
		return ItemBuilder.isReady() && ItemCache.isReady() && EntityCreator.isReady() && AbilityCreator.isReady() && SoulPowerCompiler.isReady();
	}

	/**
	 * Checks whether the given entity is registered as a rare by RareSpawns.
	 *
	 * @param entity the entity to check
	 * @return {@code true} if the entity is rare, {@code false} otherwise
	 */
	public static boolean isRare(Entity entity) {
		return RareSpawns.isRare(entity);
	}

	/**
	 * Checks whether the given item is registered as a rare item by RareSpawns.
	 *
	 * @param item the item to check
	 * @return {@code true} if the item is rare, {@code false} otherwise
	 */
	public static boolean isRare(ItemStack item) {
		return RareSpawns.isRare(item);
	}

	/**
	 * Retrieves the unique rare ID associated with a given entity.
	 *
	 * @param entity the entity to query
	 * @return the rare ID string, or {@code null} if the entity is not rare
	 */
	public static String getRareID(Entity entity) {
		return RareSpawns.getRareID(entity);
	}

	/**
	 * Retrieves the unique rare ID associated with a given item.
	 *
	 * @param item the item to query
	 * @return the rare ID string, or {@code null} if the item is not a RareSpawns item
	 */
	public static String getRareID(ItemStack item) {
		return RareSpawns.getRareID(item);
	}

	/**
	 * Retrieves an item defined by its ID.
	 * <p>
	 * If {@code randomize} is true, a randomized variant is built using {@link ItemBuilder};
	 * otherwise the fixed definition is returned via {@link ItemCache}.
	 * </p>
	 *
	 * @param id the item ID
	 * @param randomize whether the item should be randomized, if applicable
	 * @return the constructed {@link ItemStack}, or {@code null} if not found
	 */
	public static ItemStack getItem(String id, boolean randomize) {
		if(randomize) return ItemBuilder.build(id);
		else return ItemCache.getItem(id);
	}

	/**
	 * Fetches the immutable configuration/data model for a RareSpawns item.
	 * <p>
	 * Use this to inspect definition-time properties (lore template, flags, rarity,
	 * update toggle, etc.) without constructing a live {@link ItemStack}. For an
	 * actual in-game item instance use {@link #getItem(String, boolean)}.
	 * </p>
	 *
	 * @param id the item identifier (file name without extension)
	 * @return the {@link ItemData} model, or {@code null} if no item with that id exists
	 */
	public static ItemData getItemData(String id) {
		return ItemCache.getItemData(id);
	}

	/**
	 * Retrieves a list of all available item IDs.
	 *
	 * @return a list of item ID strings (never null)
	 */
	public static List<String> getItemIds(){
		return ItemBuilder.listItems();
	}

	/**
	 * Retrieves the data model for a rare entity by ID.
	 *
	 * @param id the rare entity ID
	 * @return the {@link EntityData} representing the entity, or {@code null} if not found
	 */
	public static EntityData getRare(String id) {
		return EntityCreator.getEntity(id);
	}

	/**
	 * Retrieves a list of all available rare entity IDs.
	 *
	 * @return a list of rare entity ID strings (never null)
	 */
	public static List<String> getRareIds(){
		return EntityCreator.listEntities();
	}

	/**
	 * Retrieves a list of all available ability IDs.
	 *
	 * @return a list of ability ID strings (never null)
	 */
	public static List<String> getAbilityIds(){
		return AbilityCreator.listAbilities();
	}

	/**
	 * Retrieves the metadata for an ability by ID.
	 *
	 * @param id the ability ID
	 * @return the {@link AbilityInfo} representing the ability, or {@code null} if not found
	 */
	public static AbilityInfo AbilityInfo(String id) {
		return AbilityInfo.getAbilityInfo(id);
	}

	/**
	 * Retrieves a list of all available soul power IDs.
	 *
	 * @return a list of soul power ID strings (never null)
	 */
	public static List<String> getPowerIds(){
		return SoulPowerCompiler.listPowers();
	}

	/**
	 * Retrieves the metadata for a soul power by ID.
	 *
	 * @param id the soul power ID
	 * @return the {@link SoulPowerInfo} representing the soul power, or {@code null} if not found
	 */
	public static SoulPowerInfo getSoulPowerInfo(String id) {
		return SoulPowerInfo.getAbilityInfo(id);
	}

	/**
	 * Spawns the rare defined by the provided ID at the given location.
	 * <p>
	 * This is considered an {@code EXTERNAL} spawn (spawned through the public API).
	 * Implementations may fire {@link valorless.rarespawns.api.events.RareSpawnEvent}
	 * with {@code cause = EXTERNAL}.
	 * </p>
	 * <p>
	 * Requirements: call on the main thread; {@code id} must exist; {@code location}
	 * and its world must be non-null.
	 * </p>
	 *
	 * @param id the rare entity ID to spawn
	 * @param location the world location where the rare should spawn
	 */
	public static LivingEntity spawnRare(String id, Location location) {
		return EntityCreator.spawnRare(id, location);
	}

	/**
	 * Updates the given rare entity's data based on its registered definition.
	 * <p>
	 * This is useful for refreshing a rare's properties (health, abilities, etc.)
	 * after changes to its definition or external modifications.
	 * </p>
	 *
	 * @param rare the living entity to update
	 */
	public static void updateRare(LivingEntity rare){
		EntityCreator.updateEntity(rare, getRareID(rare), false);
	}
}