package valorless.rarespawns.api;

import net.md_5.bungee.api.ChatMessageType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import valorless.rarespawns.Lang;
import valorless.rarespawns.Main;
import valorless.rarespawns.annotations.Nullable;
import valorless.rarespawns.datamodels.Message;
import valorless.rarespawns.datamodels.Sound;
import valorless.valorlessutils.logging.Log;
import valorless.valorlessutils.types.Vector3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Utility methods for applying common in-game effects and checks.
 * <p>
 * This class groups helper methods used by RareSpawns to interact with Bukkit/Spigot
 * entities and locations: potion effects, particles, sounds, damage/teleport helpers,
 * and a variety of convenience predicates (e.g. biome/time/entity category checks).
 * </p>
 *
 * <h2>Error handling</h2>
 * <p>
 * All methods are defensive: exceptions are caught, logged through
 * {@link valorless.valorlessutils.ValorlessUtils.Log}, and the method returns a
 * sensible fallback value (typically {@code false}, {@code 0}, or {@code -1}) rather
 * than propagating the exception.
 * </p>
 *
 * <h2>Threading</h2>
 * <p>
 * Many Bukkit API calls must be performed on the server/main thread.
 * Callers are responsible for ensuring correct thread usage.
 * </p>
 *
 * @since 1.0.0.beta.939
 */
public class EffectUtils {

	/**
	 * Logs the exception and prints the stack trace.
	 *
	 * @param e exception to log
	 * @return always {@code false} (convenience for callers)
	 */
	private static boolean stackTrace(Exception e) {
		Log.error(Main.plugin, "An error occurred while applying an effect:");
		e.printStackTrace();
		return false;
	}

	/**
	 * Computes the angle (in radians) between the facing directions of two entities.
	 *
	 * @param e1 first entity
	 * @param e2 second entity
	 * @return angle in radians, or {@code -1} on error
	 */
	public static double angleBetween(Entity e1, Entity e2) {
		try {
			Vector dir1 = e1.getLocation().getDirection().normalize();
			Vector dir2 = e2.getLocation().getDirection().normalize();
			double dot = dir1.dot(dir2);
			return Math.acos(dot);
		} catch (Exception e) {
			return stackTrace(e) ? -1 : -1;
		}
	}

	/**
	 * Computes the angle (in radians) between the facing directions of two locations.
	 * <p>
	 * Note: a {@link Location} only has a direction if it has yaw/pitch set.
	 * </p>
	 *
	 * @param l1 first location
	 * @param l2 second location
	 * @return angle in radians, or {@code -1} on error
	 */
	public static double angleBetween(Location l1, Location l2) {
		try {
			Vector dir1 = l1.getDirection().normalize();
			Vector dir2 = l2.getDirection().normalize();
			double dot = dir1.dot(dir2);
			return Math.acos(dot);
		} catch (Exception e) {
			return stackTrace(e) ? -1 : -1;
		}
	}

	/**
	 * Applies a potion effect by name.
	 * <p>
	 * The {@code level} is 1-based (Minecraft amplifier is 0-based), so this method
	 * uses {@code level - 1} as the amplifier.
	 * </p>
	 *
	 * @param effect effect name (case-insensitive). Example: "SPEED"
	 * @param level  1-based level
	 * @param duration duration in ticks
	 * @param target target entity
	 * @param override if {@code true}, an existing effect of the same type is removed first
	 * @return {@code true} if applied; {@code false} if invalid effect or on error
	 */
	@SuppressWarnings("deprecation")
	public static boolean applyPotionEffect(String effect, int level, int duration, LivingEntity target, boolean override) {
		try {
			PotionEffectType type = null;
			try {
				type = PotionEffectType.getByName(effect.toUpperCase());
			} catch (Exception e) {
				try {
					for(PotionEffectType t : PotionEffectType.values()) {
						if(t.getName().equalsIgnoreCase(effect)) {
							type = t;
							break;
						}
					}
				} catch (Exception E) {
					try {
						for(PotionEffectType t : Registry.EFFECT) {
							if(t.getName().equalsIgnoreCase(effect)) {
								type = t;
								break;
							}
						}
					} catch (Exception é) {
						return stackTrace(é);
					}
				}
			}

			if(type == null) {
				Log.error(Main.plugin, "Invalid potion effect: " + effect);
				return false;
			}

			if(override) {
				target.removePotionEffect(type);
			}
			target.addPotionEffect(new PotionEffect(type, duration, level - 1));
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Applies a potion effect by type.
	 * <p>
	 * The {@code level} is 1-based (Minecraft amplifier is 0-based), so this method
	 * uses {@code level - 1} as the amplifier.
	 * </p>
	 *
	 * @param effect effect type
	 * @param level  1-based level
	 * @param duration duration in ticks
	 * @param target target entity
	 * @param override if {@code true}, an existing effect of the same type is removed first
	 * @return {@code true} if applied; {@code false} on error
	 */
	public static boolean applyPotionEffect(PotionEffectType effect, int level, int duration, LivingEntity target, boolean override) {
		try {
			if(override) {
				target.removePotionEffect(effect);
			}
			target.addPotionEffect(new PotionEffect(effect, duration, level - 1));
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns a red dust particle effect at the middle of the entity (visual "bleed").
	 *
	 * @param target target entity
	 * @param amount currently unused (reserved for future scaling)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean bleed(LivingEntity target, double amount) {
		try {
			Location loc = target.getLocation().add(0, target.getHeight() / 2, 0);
			target.getWorld().spawnParticle(Particle.DUST, loc, 0, 0.5, 0.5, 0.5, 1, new Particle.DustOptions(org.bukkit.Color.RED, 1));
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Sets the entity on fire.
	 *
	 * @param ticks fire duration in ticks
	 * @param target target entity
	 * @return {@code true} if applied; {@code false} on error
	 */
	public static boolean burn(int ticks, Entity target) {
		try {
			target.setFireTicks(ticks);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Dispatches a command from the server console.
	 *
	 * @param command raw command string
	 * @return {@code true} if dispatched; {@code false} on error
	 */
	public static boolean consoleCommand(String command) {
		try {
			Main.plugin.getServer().dispatchCommand(Main.plugin.getServer().getConsoleSender(), command);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Damages a living entity using Bukkit's {@link LivingEntity#damage(double)}.
	 *
	 * @param target target entity
	 * @param damage amount of damage
	 * @return {@code true} if applied; {@code false} on error
	 */
	public static boolean damage(LivingEntity target, double damage) {
		try {
			target.damage(damage);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Damages living entities within a cone around the source's look direction.
	 *
	 * @param source source entity (cone origin + direction)
	 * @param radius search radius
	 * @param angle cone angle in degrees
	 * @param damage damage to apply
	 * @return {@code true} if processed; {@code false} on error
	 */
	public static boolean damageCone(Entity source, double radius, double angle, double damage) {
		try {
			List<Entity> targets = source.getNearbyEntities(radius, radius, radius);
			Vector sourceDir = source.getLocation().getDirection().normalize();
			for(Entity e : targets) {
				if(e instanceof LivingEntity) {
					Vector toTarget = e.getLocation().toVector().subtract(source.getLocation().toVector()).normalize();
					double dot = sourceDir.dot(toTarget);
					double targetAngle = Math.acos(dot);
					if(targetAngle <= Math.toRadians(angle / 2)) {
						damage((LivingEntity) e, damage);
					}
				}
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Calculates damage based on distance from a source entity to a target location.
	 *
	 * @param source source entity
	 * @param location target location
	 * @param baseDamage base damage at zero distance
	 * @param multiplier damage increase per block of distance
	 * @return calculated damage, or {@code baseDamage} on error
	 */
	public static double damageDistance(Entity source, Location location, double baseDamage, double multiplier) {
		try {
			double distance = source.getLocation().distance(location);
			double damage = baseDamage + distance * multiplier;
			return damage;
		} catch (Exception e) {
			return stackTrace(e) ? baseDamage : baseDamage;
		}
	}

	/**
	 * Damages all living entities within a radius.
	 *
	 * @param center center point
	 * @param radius radius in blocks
	 * @param damage damage per entity
	 * @return {@code true} if processed; {@code false} on error
	 */
	public static boolean damageRadius(Location center, double radius, double damage) {
		try {
			List<Entity> targets = center.getWorld().getNearbyEntities(center, radius, radius, radius).stream().toList();
			for(Entity e : targets) {
				if(e instanceof LivingEntity) {
					damage((LivingEntity) e, damage);
				}
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Decreases a value by a percentage.
	 *
	 * @param value base value
	 * @param percentage percentage to subtract (e.g. 25 => value * 0.75)
	 * @return decreased value (or original value on error)
	 */
	public static double decreaseBy(double value, double percentage) {
		try {
			return value * (1 - percentage / 100);
		} catch (Exception e) {
			return stackTrace(e) ? value : value;
		}
	}

	/**
	 * Temporarily sets knockback resistance to 1.0 for the given duration.
	 *
	 * @param entity target entity
	 * @param ticks duration in ticks
	 * @return {@code true} if scheduled; {@code false} on error
	 */
	@SuppressWarnings("deprecation")
	public static boolean disableKnockback(LivingEntity entity, int ticks) {
		try {
			Attribute att;
			try {
				att = Attribute.valueOf("GENERIC_KNOCKBACK_RESISTANCE");
			} catch (Exception e) {
				att = Attribute.valueOf("KNOCKBACK_RESISTANCE");
			}
			final double originalResist = entity.getAttribute(att).getBaseValue();
			entity.getAttribute(att).setBaseValue(1);
			final Attribute a = att;
			Main.plugin.getServer().getScheduler().runTaskLater(Main.plugin, () -> {
				try {
					entity.getAttribute(a).setBaseValue(originalResist); // Reset to default speed after freeze duration.
				} catch (Exception e) {
					stackTrace(e);
				}
			}, ticks);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Measures distance between two entities.
	 *
	 * @param e1 first entity
	 * @param e2 second entity
	 * @return distance, or {@code -1} on error
	 */
	public static double distance(Entity e1, Entity e2) {
		try {
			return e1.getLocation().distance(e2.getLocation());
		} catch (Exception e) {
			return stackTrace(e) ? -1 : -1;
		}
	}

	/**
	 * Measures distance between two locations.
	 *
	 * @param l1 first location
	 * @param l2 second location
	 * @return distance, or {@code -1} on error
	 */
	public static double distance(Location l1, Location l2) {
		try {
			return l1.distance(l2);
		} catch (Exception e) {
			return stackTrace(e) ? -1 : -1;
		}
	}

	/**
	 * Spawns an {@link ExperienceOrb} at the given location.
	 *
	 * @param location spawn location
	 * @param amount experience amount
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean dropExperience(Location location, int amount) {
		try {
			location.getWorld().spawn(location, ExperienceOrb.class).setExperience(amount);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Creates an explosion at the location.
	 *
	 * @param location explosion location
	 * @param power explosion power
	 * @param setFire whether to set fire
	 * @param breakBlocks whether blocks can be broken
	 * @return {@code true} if created; {@code false} on error
	 */
	public static boolean explode(Location location, float power, boolean setFire, boolean breakBlocks) {
		try {
			location.getWorld().createExplosion(location, power, setFire, breakBlocks);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Extinguishes an entity by setting its fire ticks to 0.
	 *
	 * @param entity target entity
	 * @return {@code true} if applied; {@code false} on error
	 */
	public static boolean extinguish(Entity entity) {
		try {
			entity.setFireTicks(0);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Temporarily sets movement speed to 0 for the given duration.
	 *
	 * @param entity target entity
	 * @param ticks duration in ticks
	 * @return {@code true} if scheduled; {@code false} on error
	 */
	@SuppressWarnings("deprecation")
	public static boolean freeze(LivingEntity entity, int ticks) {
		try {
			Attribute att;
			try {
				att = Attribute.valueOf("GENERIC_MOVEMENT_SPEED");
			} catch (Exception e) {
				att = Attribute.valueOf("MOVEMENT_SPEED");
			}
			final double originalSpeed = entity.getAttribute(att).getBaseValue();
			entity.getAttribute(att).setBaseValue(0);
			final Attribute a = att;
			Main.plugin.getServer().getScheduler().runTaskLater(Main.plugin, () -> {
				try {
					entity.getAttribute(a).setBaseValue(originalSpeed); // Reset to default speed after freeze duration.
				} catch (Exception e) {
					stackTrace(e);
				}
			}, ticks);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks if the source has a direct line of sight to the target.
	 *
	 * @param source source living entity
	 * @param target target entity
	 * @return {@code true} if visible, otherwise {@code false}
	 */
	public static boolean hasLineOfSight(LivingEntity source, Entity target) {
		try {
			return source.hasLineOfSight(target);
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks if a straight ray between two locations is unobstructed by blocks.
	 *
	 * @param source source location
	 * @param target target location
	 * @return {@code true} if unobstructed, otherwise {@code false}
	 */
	public static boolean hasLineOfSight(Location source, Location target) {
		try {
			return source.getWorld().rayTraceBlocks(source, target.toVector().subtract(source.toVector()).normalize(), source.distance(target)) == null;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Returns current health divided by max health.
	 *
	 * @param entity entity to check
	 * @return health percentage in range [0..1], or 0 on error / non-living
	 */
	@SuppressWarnings("deprecation")
	public static double healthPercentage(Entity entity) {
		try {
			if(entity instanceof LivingEntity) {
				LivingEntity le = (LivingEntity) entity;
				Attribute att;
				try {
					att = Attribute.valueOf("GENERIC_MAX_HEALTH");
				} catch (Exception e) {
					att = Attribute.valueOf("MAX_HEALTH");
				}
				return le.getHealth() / le.getAttribute(att).getValue();
			}
			return 0;
		} catch (Exception e) {
			return stackTrace(e) ? 0 : 0;
		}
	}

	/**
	 * Increases a value by a percentage.
	 *
	 * @param value base value
	 * @param percentage percentage to add (e.g. 25 => value * 1.25)
	 * @return increased value (or original value on error)
	 */
	public static double increaseBy(double value, double percentage) {
		try {
			return value * (1 + percentage / 100);
		} catch (Exception e) {
			return stackTrace(e) ? value : value;
		}
	}

	/**
	 * Checks whether the given location is at or above the world's sea level.
	 *
	 * @param location location to check
	 * @return {@code true} if Y is at or above sea level
	 */
	public static boolean isAboveGround(Location location) {
		try {
			return location.getY() >= location.getWorld().getSeaLevel();
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered an aquatic mob.
	 *
	 * @param entity entity to check
	 * @return {@code true} if the entity is considered aquatic
	 */
	public static boolean isAquatic(Entity entity) {
		try {
			return entity instanceof WaterMob || entity instanceof Guardian || entity instanceof ElderGuardian || entity instanceof Squid || entity instanceof Dolphin || entity instanceof Turtle || entity instanceof Salmon || entity instanceof Cod || entity instanceof PufferFish || entity instanceof TropicalFish;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered an arthropod.
	 *
	 * @param entity entity to check
	 * @return {@code true} if the entity is considered an arthropod
	 */
	public static boolean isArthropod(Entity entity) {
		try {
			return entity instanceof Spider || entity instanceof CaveSpider || entity instanceof Silverfish || entity instanceof Endermite;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered a boss.
	 *
	 * @param entity entity to check
	 * @return {@code true} if the entity is considered a boss
	 */
	public static boolean isBoss(Entity entity) {
		try {
			return entity instanceof EnderDragon || entity instanceof Wither;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether it's currently daytime at the given location.
	 *
	 * @param location location to check
	 * @return {@code true} if world time is day (0..12299)
	 */
	public static boolean isDaytime(Location location) {
		try {
			long time = location.getWorld().getTime();
			return time >= 0 && time < 12300;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered a flying mob.
	 *
	 * @param entity entity to check
	 * @return {@code true} if the entity is considered flying
	 */
	public static boolean isFlying(Entity entity) {
		try {
			return entity instanceof Phantom || entity instanceof Ghast || entity instanceof Blaze || entity instanceof Vex;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered hostile.
	 *
	 * @param entity entity to check
	 * @return {@code true} if the entity is considered hostile
	 */
	public static boolean isHostile(Entity entity) {
		try {
			return entity instanceof Monster || entity instanceof EnderDragon || entity instanceof Wither;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the given entity is airborne (not on ground and not in liquids).
	 *
	 * @param entity entity to check
	 * @return {@code true} if not on ground and not in water/lava
	 */
	public static boolean isInAir(Entity entity) {
		try {
			return !entity.isOnGround() && !isInWater(entity) && !isInLava(entity);
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the entity's current block is lava.
	 *
	 * @param entity entity to check
	 * @return {@code true} if the entity's current block type contains "LAVA"
	 */
	public static boolean isInLava(Entity entity) {
		try {
			return entity.getLocation().getBlock().getType().toString().contains("LAVA");
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the entity is currently inside a liquid block.
	 *
	 * @param entity entity to check
	 * @return {@code true} if the entity's current block is liquid
	 */
	public static boolean isInWater(Entity entity) {
		try {
			return entity.getLocation().getBlock().isLiquid();
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the given entity is a {@link LivingEntity}.
	 *
	 * @param entity entity
	 * @return {@code true} if entity is a {@link LivingEntity}
	 */
	public static boolean isLivingEntity(Entity entity) {
		try {
			return entity instanceof LivingEntity;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered a mount (rideable) entity.
	 *
	 * @param entity entity
	 * @return {@code true} if entity is considered a mount
	 */
	public static boolean isMount(Entity entity) {
		try {
			return entity instanceof Horse || entity instanceof Donkey || entity instanceof Mule || entity instanceof Llama || entity instanceof Pig || entity instanceof Strider;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered neutral.
	 *
	 * @param entity entity
	 * @return {@code true} if entity is considered neutral
	 */
	public static boolean isNeutral(Entity entity) {
		try {
			return entity instanceof PigZombie || entity instanceof Enderman || entity instanceof Wolf;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether it's currently nighttime at the given location.
	 *
	 * @param location location
	 * @return {@code true} if world time is night (12300..23849)
	 */
	public static boolean isNighttime(Location location) {
		try {
			long time = location.getWorld().getTime();
			return time >= 12300 && time < 23850;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether Bukkit reports the given entity is on the ground.
	 *
	 * @param entity entity
	 * @return {@code true} if Bukkit reports the entity is on the ground
	 */
	public static boolean isOnGround(Entity entity) {
		try {
			return entity.isOnGround();
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered passive.
	 *
	 * @param entity entity
	 * @return {@code true} if entity is considered passive
	 */
	public static boolean isPassive(Entity entity) {
		try {
			return entity instanceof Animals || entity instanceof WaterMob || entity instanceof Ambient;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the given entity is a player.
	 *
	 * @param entity entity
	 * @return {@code true} if entity is a {@link Player}
	 */
	public static boolean isPlayer(Entity entity) {
		try {
			return entity instanceof Player;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the world at the given location currently has a storm.
	 *
	 * @param location location
	 * @return {@code true} if the world currently has a storm
	 */
	public static boolean isRaining(Location location) {
		try {
			return location.getWorld().hasStorm();
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the given entity can be tamed (implements {@link Tameable}).
	 *
	 * @param entity entity
	 * @return {@code true} if entity implements {@link Tameable}
	 */
	public static boolean isTameable(Entity entity) {
		try {
			return entity instanceof Tameable;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the given entity is a tamed {@link Tameable}.
	 *
	 * @param entity entity
	 * @return {@code true} if entity is a tamed {@link Tameable}
	 */
	public static boolean isTamed(Entity entity) {
		try {
			if(entity instanceof Tameable) {
				return ((Tameable) entity).isTamed();
			}
			return false;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the world at the given location is currently thundering.
	 *
	 * @param location location
	 * @return {@code true} if the world is thundering
	 */
	public static boolean isThundering(Location location) {
		try {
			return location.getWorld().isThundering();
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Determines whether the given entity is considered undead.
	 *
	 * @param entity entity
	 * @return {@code true} if entity is considered undead
	 */
	public static boolean isUndead(Entity entity) {
		try {
			return entity instanceof Zombie || entity instanceof Skeleton || entity instanceof WitherSkeleton || entity instanceof Ghast || entity instanceof PigZombie;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Checks whether the given location is below sea level.
	 *
	 * @param location location
	 * @return {@code true} if below sea level
	 */
	public static boolean isUnderground(Location location) {
		try {
			return location.getY() < location.getWorld().getSeaLevel();
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Kills an entity.
	 * <p>
	 * For living entities this sets health to 0, otherwise it removes the entity.
	 * </p>
	 *
	 * @param target target entity
	 * @return {@code true} if killed/removed; {@code false} on error
	 */
	public static boolean kill(Entity target) {
		try {
			if(target instanceof LivingEntity) {
				((LivingEntity) target).setHealth(0);
			} else {
				target.remove();
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Kills/removes an entity, optionally skipping the death animation.
	 *
	 * @param target target entity
	 * @param noAnimation if {@code true} the entity is removed directly
	 * @return {@code true} if killed/removed; {@code false} on error
	 */
	public static boolean kill(Entity target, boolean noAnimation) {
		try {
			if(noAnimation) {
				target.remove();
			} else if(target instanceof LivingEntity) {
				((LivingEntity) target).setHealth(0);
			} else {
				target.remove();
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles by name.
	 *
	 * @param particle particle name (case-insensitive)
	 * @param location spawn location
	 * @param count number of particles
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on invalid particle or error
	 */
	public static boolean particle(String particle, Location location, int count, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			Particle type = null;
			try {
				type = Particle.valueOf(particle.toUpperCase());
			} catch (Exception e) {
				try {
					for(Particle t : Particle.values()) {
						if(t.name().equalsIgnoreCase(particle)) {
							type = t;
							break;
						}
					}
				} catch (Exception E) {
					try {
						for(Particle t : Registry.PARTICLE_TYPE) {
							if(t.name().equalsIgnoreCase(particle)) {
								type = t;
								break;
							}
						}
					} catch (Exception é) {
						return stackTrace(é);
					}
				}
			}

			if(type == null) {
				Log.error(Main.plugin, "Invalid particle: " + type);
				return false;
			}

			location.getWorld().spawnParticle(type, location, count, offsetX, offsetY, offsetZ, extra, null);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles by type.
	 *
	 * @param particle particle type
	 * @param location spawn location
	 * @param count number of particles
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean particle(Particle particle, Location location, int count, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			location.getWorld().spawnParticle(particle, location, count, offsetX, offsetY, offsetZ, extra, null);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles along a circle around a center point by particle name.
	 *
	 * @param particle particle name
	 * @param center center location
	 * @param radius circle radius
	 * @param points number of points/steps
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean particleCircle(String particle, Location center, double radius, int points, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			Particle type = null;
			try {
				type = Particle.valueOf(particle.toUpperCase());
			} catch (Exception e) {
				try {
					for(Particle t : Particle.values()) {
						if(t.name().equalsIgnoreCase(particle)) {
							type = t;
							break;
						}
					}
				} catch (Exception E) {
					try {
						for(Particle t : Registry.PARTICLE_TYPE) {
							if(t.name().equalsIgnoreCase(particle)) {
								type = t;
								break;
							}
						}
					} catch (Exception é) {
						return stackTrace(é);
					}
				}
			}

			if(type == null) {
				Log.error(Main.plugin, "Invalid particle: " + type);
				return false;
			}

			for(int i = 0; i < points; i++) {
				double angle = 2 * Math.PI * i / points;
				double x = center.getX() + radius * Math.cos(angle);
				double z = center.getZ() + radius * Math.sin(angle);
				center.getWorld().spawnParticle(type, x, center.getY(), z, 0, offsetX, offsetY, offsetZ, extra, null);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles along a circle around a center point by particle type.
	 *
	 * @param particle particle type
	 * @param center center location
	 * @param radius circle radius
	 * @param points number of points/steps
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean particleCircle(Particle particle, Location center, double radius, int points, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			for(int i = 0; i < points; i++) {
				double angle = 2 * Math.PI * i / points;
				double x = center.getX() + radius * Math.cos(angle);
				double z = center.getZ() + radius * Math.sin(angle);
				center.getWorld().spawnParticle(particle, x, center.getY(), z, 0, offsetX, offsetY, offsetZ, extra, null);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles along a line between two points (name overload).
	 *
	 * @param particle particle name
	 * @param start start location
	 * @param end end location
	 * @param points number of points to sample
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean particleLine(String particle, Location start, Location end, int points, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			Particle type = null;
			try {
				type = Particle.valueOf(particle.toUpperCase());
			} catch (Exception e) {
				try {
					for(Particle t : Particle.values()) {
						if(t.name().equalsIgnoreCase(particle)) {
							type = t;
							break;
						}
					}
				} catch (Exception E) {
					try {
						for(Particle t : Registry.PARTICLE_TYPE) {
							if(t.name().equalsIgnoreCase(particle)) {
								type = t;
								break;
							}
						}
					} catch (Exception é) {
						return stackTrace(é);
					}
				}
			}

			if(type == null) {
				Log.error(Main.plugin, "Invalid particle: " + type);
				return false;
			}

			/* Use particleLine(Particle..) to avoid code duplication since the particle type has already been resolved. */
			return particleLine(type, start, end, points, offsetX, offsetY, offsetZ, extra);
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles along a line between two points.
	 *
	 * @param particle particle type
	 * @param start start location
	 * @param end end location
	 * @param points number of points to sample
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean particleLine(Particle particle, Location start, Location end, int points, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			Vector3<Double> dir = new Vector3<>(end.getX() - start.getX(), end.getY() - start.getY(), end.getZ() - start.getZ());
			double length = Math.sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
			dir = new Vector3<>(dir.x / length, dir.y / length, dir.z / length); // Normalize direction vector.

			for(int i = 0; i <= points; i++) {
				double t = (double) i / points;
				Location point = new Location(start.getWorld(), start.getX() + dir.x * length * t, start.getY() + dir.y * length * t, start.getZ() + dir.z * length * t);
				point.getWorld().spawnParticle(particle, point, 0, offsetX, offsetY, offsetZ, extra, null);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles randomly distributed on a sphere surface (name overload).
	 *
	 * @param particle particle name
	 * @param center center location
	 * @param radius sphere radius
	 * @param points number of particles/points
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean particleSphere(String particle, Location center, double radius, int points, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			Particle type = null;
			try {
				type = Particle.valueOf(particle.toUpperCase());
			} catch (Exception e) {
				try {
					for(Particle t : Particle.values()) {
						if(t.name().equalsIgnoreCase(particle)) {
							type = t;
							break;
						}
					}
				} catch (Exception E) {
					try {
						for(Particle t : Registry.PARTICLE_TYPE) {
							if(t.name().equalsIgnoreCase(particle)) {
								type = t;
								break;
							}
						}
					} catch (Exception é) {
						return stackTrace(é);
					}
				}
			}

			if(type == null) {
				Log.error(Main.plugin, "Invalid particle: " + type);
				return false;
			}

			for(int i = 0; i < points; i++) {
				double phi = Math.acos(1 - 2 * Math.random());
				double theta = 2 * Math.PI * Math.random();
				double x = center.getX() + radius * Math.sin(phi) * Math.cos(theta);
				double y = center.getY() + radius * Math.sin(phi) * Math.sin(theta);
				double z = center.getZ() + radius * Math.cos(phi);
				center.getWorld().spawnParticle(type, x, y, z, 0, offsetX, offsetY, offsetZ, extra, null);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns particles randomly distributed on a sphere surface.
	 *
	 * @param particle particle type
	 * @param center center location
	 * @param radius sphere radius
	 * @param points number of particles/points
	 * @param offsetX offset X
	 * @param offsetY offset Y
	 * @param offsetZ offset Z
	 * @param extra extra data (speed)
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean particleSphere(Particle particle, Location center, double radius, int points, double offsetX, double offsetY, double offsetZ, double extra) {
		try {
			for(int i = 0; i < points; i++) {
				double phi = Math.acos(1 - 2 * Math.random());
				double theta = 2 * Math.PI * Math.random();
				double x = center.getX() + radius * Math.sin(phi) * Math.cos(theta);
				double y = center.getY() + radius * Math.sin(phi) * Math.sin(theta);
				double z = center.getZ() + radius * Math.cos(phi);
				center.getWorld().spawnParticle(particle, x, y, z, 0, offsetX, offsetY, offsetZ, extra, null);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Plays a sound at a location.
	 *
	 * @param location target location
	 * @param sound sound id/string understood by {@link Sound#parse(String)}
	 * @param volume volume
	 * @param pitch pitch
	 * @return {@code true} if played; {@code false} on error
	 */
	public static boolean playSound(Location location, String sound, float volume, float pitch) {
		try {
			Sound s = Sound.parse(String.format("%s:%s:%s", sound, volume, pitch));
			s.play(location);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Plays a sound to a player.
	 *
	 * @param player target player
	 * @param sound sound id/string understood by {@link Sound#parse(String)}
	 * @param volume volume
	 * @param pitch pitch
	 * @return {@code true} if played; {@code false} on error
	 */
	public static boolean playSound(Player player, String sound, float volume, float pitch) {
		try {
			Sound s = Sound.parse(String.format("%s:%s:%s", sound, volume, pitch));
			s.play(player);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Has the player perform a command.
	 *
	 * @param command command to execute
	 * @param player command sender
	 * @return {@code true} if performed; {@code false} on error
	 */
	public static boolean playerCommand(String command, Player player) {
		try {
			player.performCommand(command);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns a projectile entity by type name.
	 *
	 * @param shooter shooter entity
	 * @param projectile entity type name, e.g. "ARROW"
	 * @param speed velocity multiplier
	 * @param direct if {@code true} sets velocity directly, otherwise adds to existing velocity
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean projectile(Entity shooter, String projectile, double speed, boolean direct) {
		try {
			Vector dir = shooter.getLocation().getDirection().normalize().multiply(speed);
			Entity proj = shooter.getWorld().spawnEntity(shooter.getLocation().add(dir), EntityType.valueOf(projectile.toUpperCase()));
			if(direct) {
				proj.setVelocity(dir);
			} else {
				proj.setVelocity(proj.getVelocity().add(dir));
			}
			proj.setRotation(shooter.getLocation().getYaw(), shooter.getLocation().getPitch());
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Spawns a projectile entity by {@link EntityType}.
	 *
	 * @param shooter shooter entity
	 * @param projectile projectile entity type
	 * @param speed velocity multiplier
	 * @param direct if {@code true} sets velocity directly, otherwise adds to existing velocity
	 * @return {@code true} if spawned; {@code false} on error
	 */
	public static boolean projectile(Entity shooter, EntityType projectile, double speed, boolean direct) {
		try {
			Vector dir = shooter.getLocation().getDirection().normalize().multiply(speed);
			Entity proj = shooter.getWorld().spawnEntity(shooter.getLocation().add(dir), projectile);
			if(direct) {
				proj.setVelocity(dir);
			} else {
				proj.setVelocity(proj.getVelocity().add(dir));
			}
			proj.setRotation(shooter.getLocation().getYaw(), shooter.getLocation().getPitch());
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Pulls the target towards the source by setting/adding velocity.
	 *
	 * @param source source entity
	 * @param target target entity
	 * @param strength velocity multiplier
	 * @param relative if {@code true} adds to current velocity, otherwise overrides it
	 * @return {@code true} if applied; {@code false} on error
	 */
	public static boolean pullCloser(Entity source, Entity target, double strength, boolean relative) {
		try {
			Vector dir = source.getLocation().toVector().subtract(target.getLocation().toVector()).normalize().multiply(strength);
			if(relative) {
				target.setVelocity(target.getVelocity().add(dir));
			} else {
				target.setVelocity(dir);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Pushes the target away from the source by setting/adding velocity.
	 *
	 * @param source source entity
	 * @param target target entity
	 * @param strength velocity multiplier
	 * @param relative if {@code true} adds to current velocity, otherwise overrides it
	 * @return {@code true} if applied; {@code false} on error
	 */
	public static boolean pushAway(Entity source, Entity target, double strength, boolean relative) {
		try {
			Vector dir = target.getLocation().toVector().subtract(source.getLocation().toVector()).normalize().multiply(strength);
			if(relative) {
				target.setVelocity(target.getVelocity().add(dir));
			} else {
				target.setVelocity(dir);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Removes a potion effect by type.
	 *
	 * @param effect effect type
	 * @param target target entity
	 * @return {@code true} if removed; {@code false} on error
	 */
	public static boolean removePotionEffect(PotionEffectType effect, LivingEntity target) {
		try {
			target.removePotionEffect(effect);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Removes a potion effect by name.
	 *
	 * @param effect effect name (case-insensitive)
	 * @param target target entity
	 * @return {@code true} if removed; {@code false} if invalid effect or on error
	 */
	@SuppressWarnings("deprecation")
	public static boolean removePotionEffect(String effect, LivingEntity target) {
		try {
			PotionEffectType type = null;
			try {
				type = PotionEffectType.getByName(effect.toUpperCase());
			} catch (Exception e) {
				try {
					for(PotionEffectType t : PotionEffectType.values()) {
						if(t.getName().equalsIgnoreCase(effect)) {
							type = t;
							break;
						}
					}
				} catch (Exception E) {
					try {
						for(PotionEffectType t : Registry.EFFECT) {
							if(t.getName().equalsIgnoreCase(effect)) {
								type = t;
								break;
							}
						}
					} catch (Exception é) {
						return stackTrace(é);
					}
				}
			}

			if(type == null) {
				Log.error(Main.plugin, "Invalid potion effect: " + effect);
				return false;
			}

			target.removePotionEffect(type);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Sends an action bar message to the player.
	 *
	 * @param player target player
	 * @param message message (supports language parsing)
	 * @return {@code true} if sent; {@code false} on error
	 */
	public static boolean sendActionBar(Player player, String message) {
		try {
			Message msg = new Message(ChatMessageType.ACTION_BAR,
					Lang.parse(message, player)
				);
			msg.Send(player);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Sends a chat message to the player.
	 *
	 * @param player target player
	 * @param message message (supports language parsing)
	 * @return {@code true} if sent; {@code false} on error
	 */
	public static boolean sendMessage(Player player, String message) {
		try {
			player.sendMessage(Lang.parse(message, player));
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Sends a title/subtitle to the player.
	 *
	 * @param player target player
	 * @param title title text (nullable)
	 * @param subtitle subtitle text (nullable)
	 * @param fadeIn fade in ticks
	 * @param stay stay ticks
	 * @param fadeOut fade out ticks
	 * @return {@code true} if sent; {@code false} on error
	 */
	public static boolean sendTitle(Player player, @Nullable String title, @Nullable String subtitle, int fadeIn, int stay, int fadeOut) {
		try {
			player.sendTitle(Lang.parse(title, player), Lang.parse(subtitle, player), fadeIn, stay, fadeOut);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Randomly shuffles the player's hotbar (first 9 inventory slots).
	 *
	 * @param player target player
	 * @return {@code true} if shuffled; {@code false} on error
	 */
	public static boolean shuffleHotbar(Player player) {
		try {
	        ItemStack[] hotbar = new ItemStack[9];

	        for (int i = 0; i < 9; i++) {
	            hotbar[i] = player.getInventory().getItem(i);
	        }

	        List<ItemStack> hotbarList = new ArrayList<>();
	        Collections.addAll(hotbarList, hotbar);
	        Collections.shuffle(hotbarList);

	        for (int i = 0; i < 9; i++) {
	            player.getInventory().setItem(i, hotbarList.get(i));
	        }
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Strikes lightning at the location.
	 *
	 * @param location target location
	 * @param effectOnly if {@code true}, only plays the effect (no damage)
	 * @return {@code true} if executed; {@code false} on error
	 */
	public static boolean strikeLightning(Location location, boolean effectOnly) {
		try {
			if(effectOnly) {
				location.getWorld().strikeLightningEffect(location);
			} else {
				location.getWorld().strikeLightning(location);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Teleports an entity.
	 *
	 * @param entity entity to teleport
	 * @param location destination
	 * @return {@code true} if teleported; {@code false} on error
	 */
	public static boolean teleport(Entity entity, Location location) {
		try {
			entity.teleport(location);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Teleports the target entity above their current location.
	 *
	 * @param source unused (kept for API symmetry)
	 * @param target target entity
	 * @param distance amount to add to Y
	 * @return {@code true} if teleported; {@code false} on error
	 */
	public static boolean teleportAbove(Entity source, Entity target, double distance) {
		try {
			Location loc = target.getLocation().add(0, distance, 0);
			target.teleport(loc);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Teleports the target behind the source's facing direction.
	 *
	 * @param source source entity (direction is used)
	 * @param target target entity
	 * @param distance distance behind
	 * @return {@code true} if teleported; {@code false} on error
	 */
	public static boolean teleportBehind(Entity source, Entity target, double distance) {
		try {
			Vector dir = source.getLocation().getDirection().normalize().multiply(-distance);
			Location loc = target.getLocation().add(dir);
			target.teleport(loc);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Teleports the target in front of the source's facing direction.
	 *
	 * @param source source entity (direction is used)
	 * @param target target entity
	 * @param distance distance in front
	 * @return {@code true} if teleported; {@code false} on error
	 */
	public static boolean teleportInFront(Entity source, Entity target, double distance) {
		try {
			Vector dir = source.getLocation().getDirection().normalize().multiply(distance);
			Location loc = target.getLocation().add(dir);
			target.teleport(loc);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Teleports an entity by an offset.
	 *
	 * @param entity entity
	 * @param x x offset
	 * @param y y offset
	 * @param z z offset
	 * @return {@code true} if teleported; {@code false} on error
	 */
	public static boolean teleportRelative(Entity entity, double x, double y, double z) {
		try {
			Location loc = entity.getLocation().add(x, y, z);
			entity.teleport(loc);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Teleports an entity by an offset.
	 *
	 * @param entity entity
	 * @param offset offset vector
	 * @return {@code true} if teleported; {@code false} on error
	 */
	public static boolean teleportRelative(Entity entity, Vector3<Double> offset) {
		try {
			Location loc = entity.getLocation().add(offset.x, offset.y, offset.z);
			entity.teleport(loc);
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}

	/**
	 * Toggles a permission for a player using a temporary attachment.
	 *
	 * @param player target player
	 * @param permission permission node
	 * @return {@code true} if toggled; {@code false} on error
	 */
	public static boolean togglePermission(Player player, String permission) {
		try {
			if(player.hasPermission(permission)) {
				player.addAttachment(Main.plugin, permission, false);
			} else {
				player.addAttachment(Main.plugin, permission, true);
			}
			return true;
		} catch (Exception e) {
			return stackTrace(e);
		}
	}
}
