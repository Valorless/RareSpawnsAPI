package valorless.rarespawns.datamodels;

import java.util.HashMap;
import java.util.List;
import org.bukkit.inventory.meta.BookMeta.Generation;

/**
 * Represents the data structure for a written book item in RareSpawns.
 * Stores title, author, generation, and pages for a Minecraft written book.
 */
public class WrittenBook {

	/**
	 * The title of the book.
	 */
	private String title = null;
	/**
	 * The author of the book.
	 */
	private String author = null;
	/**
	 * The generation of the book (original, copy, etc.).
	 */
	private Generation generation = Generation.ORIGINAL;
	/**
	 * The pages of the book, mapped by page index to a list of strings (lines).
	 */
	private HashMap<Integer, List<String>> pages = new HashMap<>();
	//private List<String> pages = new ArrayList<>();
	
	/**
	 * Constructs an empty WrittenBook.
	 */
	public WrittenBook() {
	}

	/**
	 * Gets the title of the book.
	 * @return The book title.
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * Sets the title of the book.
	 * @param title The book title.
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Gets the author of the book.
	 * @return The book author.
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * Sets the author of the book.
	 * @param author The book author.
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * Gets the generation of the book.
	 * @return The book generation.
	 */
	public Generation getGeneration() {
		return generation;
	}

	/**
	 * Sets the generation of the book.
	 * @param generation The book generation.
	 */
	public void setGeneration(Generation generation) {
		this.generation = generation;
	}

	/**
	 * Gets the pages of the book.
	 * @return The pages map (index to lines).
	 */
	public HashMap<Integer, List<String>> getPages() {
		return pages;
	}

	/**
	 * Sets the pages of the book.
	 * @param pages The pages map (index to lines).
	 */
	public void setPages(HashMap<Integer, List<String>> pages) {
		this.pages = pages;
	}
	
	/**
	 * Sets a specific page by index.
	 * @param index The page index.
	 * @param page The list of lines for the page.
	 */
	public void setPage(Integer index, List<String> page) {
		this.pages.put(index, page);
	}
	
	/**
	 * Adds a new page to the end of the book.
	 * @param page The list of lines for the new page.
	 */
	public void addPage(List<String> page) {
		this.pages.put(pages.size(), page);
	}
	
	/**
	 * Removes a page by index.
	 * @param page The page index to remove.
	 */
	public void removePage(Integer page) {
		this.pages.remove(page);
	}
}