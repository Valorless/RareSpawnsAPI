package valorless.rarespawns.datamodels;

import valorless.rarespawns.builders.AbilityCreator;

/**
 * Immutable data container describing metadata about a specific ability.
 * <p>
 * This class extracts and holds information from the {@link valorless.rarespawns.ability.AbilityInfo}
 * annotation present on ability classes. It provides easy access to key properties such as the
 * ability's name, cooldown period, and whether it is single-use.
 * </p>
 */
public class AbilityInfo {
	/** The name of the ability. */
	public final String name;
	/** The cooldown period of the ability in seconds. */
	public final Double cooldown;
	/** Whether the ability is single-use. */
	public final Boolean singleUse;
	
	/**
	 * Constructs an AbilityInfo object by extracting metadata from the ability class
	 * associated with the given ID.
	 * @param id The unique ID of the ability.
	 */
	public AbilityInfo(String id) {
		valorless.rarespawns.ability.AbilityInfo info = AbilityCreator.getAbility(id).getAnnotation(valorless.rarespawns.ability.AbilityInfo.class);
		this.name = info.name();
		this.cooldown = Double.valueOf(info.cooldown());
		this.singleUse = Boolean.valueOf(info.single());
	}
	
	/**
	 * Retrieves metadata about an ability by its unique ID.
	 * @param id The unique ID of the ability.
	 * @return An AbilityInfo object containing metadata about the ability.
	 */
	public static AbilityInfo getAbilityInfo(String id) {
		return new AbilityInfo(id);
	}
}