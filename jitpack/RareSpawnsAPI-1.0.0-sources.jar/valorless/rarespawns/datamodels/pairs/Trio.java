package valorless.rarespawns.datamodels.pairs;

public class Trio<K, V, E> {

    public K key;
    public V value;
    public E extra;

    public Trio(K key, V value, E extra) {
        this.key = key;
        this.value = value;
        this.extra = extra;
    }

    @Override
    public String toString() {
        return "Trio{" + "key=" + key + ", value=" + value + ", extra=" + extra + '}';
    }
}
