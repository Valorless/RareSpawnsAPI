package valorless.rarespawns.datamodels.pairs;

public class Quad<K, V, A, B> {

    public K key;
    public V value;
    public A a;
    public B b;

    public Quad(K key, V value, A a, B b) {
        this.key = key;
        this.value = value;
        this.a = a;
        this.b = b;
    }

    @Override
    public String toString() {
        return "Quad{" + "key=" + key + ", value=" + value + ", a=" + a + ", b=" + b + '}';
    }
}
