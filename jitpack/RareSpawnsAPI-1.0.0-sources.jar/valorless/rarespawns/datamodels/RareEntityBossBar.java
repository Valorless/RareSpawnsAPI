package valorless.rarespawns.datamodels;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import valorless.rarespawns.Lang;
import valorless.rarespawns.Main;
import valorless.rarespawns.api.EntityUtils;
import valorless.rarespawns.builders.EntityCreator;
import valorless.rarespawns.persistentdatacontainer.PDC;
import valorless.valorlessutils.utils.Utils;

import java.util.HashSet;
import java.util.Set;

/**
 * Represents a boss bar for a rare entity in RareSpawns.
 * Handles creation, updating, and removal of the boss bar, including health syncing and player visibility.
 * Boss bars are shown to nearby players and automatically removed when the entity dies, is tamed, or no players are nearby.
 */
@SuppressWarnings("deprecation")
public class RareEntityBossBar {
    /**
     * The rare entity this boss bar is attached to.
     */
    private final LivingEntity rare;
    /**
     * The Bukkit BossBar instance.
     */
    private final BossBar bossBar;
    /**
     * The set of players currently viewing the boss bar.
     */
    private final Set<Player> viewers = new HashSet<>();
    /**
     * The distance (radius) within which players can see the boss bar.
     */
    private final Integer distance;
    /**
     * The Bukkit runnable task ID for updating the boss bar.
     */
    public Integer runnable;

    /**
     * Constructs a RareEntityBossBar for the given rare entity.
     * Creates the boss bar, sets its properties, and schedules updates.
     * Automatically removes the boss bar if the entity dies, is tamed, or no players are nearby.
     *
     * @param rareEntity The rare entity to attach the boss bar to.
     */
    public RareEntityBossBar(LivingEntity rareEntity) {
        this.rare = rareEntity;
        // Get the rare entity ID from persistent data
        String id = PDC.getString(rareEntity, "RareEntity");
        EntityData data = EntityCreator.getEntity(id);
        distance = data.bossbarDistance;

        // Create the boss bar with a title, color, and style
        bossBar = Bukkit.createBossBar(
            Lang.parse(data.bossbarName,null),
            data.bossbarColor,
            data.bossbarStyle
        );
        // Schedule a repeating task to update the boss bar
        runnable = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.plugin, new Runnable() {
            @Override
            public void run() {
                // Remove the boss bar if the entity is dead or null
                if(rare == null || rare.isDead()) {
                    remove();
                    Bukkit.getScheduler().cancelTask(runnable);
                    return;
                }
                // Remove the boss bar if the entity is tamed
                if (rare instanceof Tameable tameable) {
                    if(tameable.isTamed()) {
                        remove();
                        return;
                    }
                }
                // Remove the boss bar if no players are nearby
                if(EntityUtils.getPlayersInRadius(rare, distance).isEmpty()) {
                    remove();
                    return;
                }
                updateHealth();
                showToNearbyPlayers();
            }
        }, 5L, 20L);
    }

    /**
     * Updates the boss bar health to match the rare entity's health.
     * Sets the boss bar progress as a percentage of current health to max health.
     */
    public void updateHealth() {
        Attribute attri = null;
        try {
            attri = Attribute.valueOf("MAX_HEALTH");
        }catch(Exception e) {
            try {
                attri = Attribute.valueOf("GENERIC_MAX_HEALTH");
            }catch(Exception E) {
                e.printStackTrace();
            }
        }
        double maxHealth = rare.getAttribute(attri).getValue();
        double currentHealth = rare.getHealth();
        bossBar.setProgress(Utils.Clamp01(currentHealth / maxHealth)); // Set progress as a percentage
    }

    /**
     * Shows the boss bar to all players near the rare entity.
     * Adds/removes players from the boss bar based on their proximity.
     */
    public void showToNearbyPlayers() {
        Location entityLocation = rare.getLocation();
        // Find all players within the specified radius
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (rare.getWorld() == player.getWorld() && player.getLocation().distance(entityLocation) <= distance) {
                if (!viewers.contains(player)) {
                    bossBar.addPlayer(player); // Add the player to the boss bar
                    viewers.add(player); // Track that this player is viewing the boss bar
                }
            } else {
                // Remove players who leave the radius
                if (viewers.contains(player)) {
                    bossBar.removePlayer(player);
                    viewers.remove(player);
                }
            }
        }
    }

    /**
     * Removes the boss bar for all players and cleans up.
     * Clears the viewers set and removes the boss bar from all players.
     */
    public void remove() {
        bossBar.removeAll(); // Remove all players from the boss bar
        viewers.clear();
    }
}