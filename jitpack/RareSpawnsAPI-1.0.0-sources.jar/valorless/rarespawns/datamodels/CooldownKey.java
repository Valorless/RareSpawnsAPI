package valorless.rarespawns.datamodels;

import java.util.UUID;

import org.bukkit.entity.Player;

/**
 * Immutable key combining a player UUID and a Soul Power ID for cooldown maps.
 * <p>
 * Instances are used as stable keys in in-memory cooldown registries. The
 * {@link #toString()} format is "<uuid>:<power>" and is suitable for use as a
 * Map key.
 * </p>
 */
public class CooldownKey {

	/**
	 * The unique identifier of the player.
	 */
	public final UUID player;
	/**
	 * The ID of the Soul Power this key refers to.
	 */
	public final String power;
	
	/**
	 * Creates a key from a UUID and power ID.
	 *
	 * @param uuid the player's UUID
	 * @param id   the power ID
	 */
	public CooldownKey(UUID uuid, String id) {
		this.player = uuid;
		this.power = id;
	}
	
	/**
	 * Creates a key from a UUID String and power ID.
	 *
	 * @param uuid the player's UUID in string form
	 * @param id   the power ID
	 * @throws IllegalArgumentException if the UUID string is invalid
	 */
	public CooldownKey(String uuid, String id) {
		this.player = UUID.fromString(uuid);
		this.power = id;
	}
	
	/**
	 * Creates a key from a Player and power ID.
	 *
	 * @param player the player instance
	 * @param id     the power ID
	 */
	public CooldownKey(Player player, String id) {
		this.player = player.getUniqueId();
		this.power = id;
	}
	
	/**
	 * Returns a stable string key in the form "<uuid>:<power>".
	 */
	@Override
	public String toString() {
		return player.toString() + ":" + power;
	}
}