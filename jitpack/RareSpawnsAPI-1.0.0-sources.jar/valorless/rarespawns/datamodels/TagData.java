package valorless.rarespawns.datamodels;

/**
 * Represents a custom tag data structure for RareSpawns items.
 * Stores the value and type of a tag for use in item metadata.
 */
public class TagData{
	/**
	 * The value of the tag (e.g., string, integer, boolean, etc.).
	 */
	public String value;
	/**
	 * The type of the tag (e.g., "string", "integer", "boolean").
	 */
	public String type;
	
	/**
	 * Constructs a TagData object with the specified value and type.
	 * @param value The value of the tag.
	 * @param type The type of the tag.
	 */
	public TagData(String value, String type) {
		this.value = value;
		this.type = type;
	}
}