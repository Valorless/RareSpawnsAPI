package valorless.rarespawns.datamodels;

import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * Data model representing a sound to be played by RareSpawns.
 * <p>
 * Stores the sound key (namespaced or legacy) and playback controls (volume and pitch)
 * as floats compatible with the Bukkit API. Not to be confused with the
 * org.bukkit.Sound enum; this model uses string keys to support custom or
 * version-agnostic identifiers.
 * </p>
 */
public class Sound {

    /** Namespaced or legacy sound key, e.g. "minecraft:entity.player.levelup" or "ENTITY_PLAYER_LEVELUP". */
    public String key;
    /** Playback volume (float). Typical range: 0.0+; 1.0 is normal. */
    public Float volume;
    /** Playback pitch (float). Typical range: about 0.5–2.0; 1.0 is normal. */
    public Float pitch;
    
    /**
     * Creates a sound model with the given identifier and playback parameters.
     *
     * @param sound  the sound key identifier (must not be null)
     * @param volume the desired volume as Double (must not be null); converted to float
     * @param pitch  the desired pitch as Double (must not be null); converted to float
     */
    public Sound(String key, Double volume, Double pitch) {
        this.key = key;                            // store key as provided
        this.volume = volume.floatValue();             // coerce to float for Bukkit API
        this.pitch = pitch.floatValue();               // coerce to float for Bukkit API
    }
    
    /**
     * Parses a sound definition from a compact string.
     * <p>
     * Expected format: <code>key:volume:pitch</code>
     * Examples: <code>ENTITY_PLAYER_LEVELUP:0.5:1.2</code>.
     * Behavior:
     * <ul>
     *   <li>If the input does not contain a colon or does not have exactly 3 parts, the entire input is treated as the key and volume/pitch default to 1.0.</li>
     *   <li>If volume or pitch fail to parse as numbers, fall back to defaults (1.0, 1.0).</li>
     * </ul>
     * </p>
     *
     * @param string the input string to parse
     * @return a constructed Sound model based on the parsed values or sensible defaults
     */
    public static Sound parse(String string) {
        // No explicit volume/pitch provided; use the whole input as the key and default values
        if(!string.contains(":")) return new Sound(string, 1.0, 1.0);
        // Split into key, volume, pitch
        String[] parts = string.split(":");
        if(parts.length != 3) return new Sound(string, 1.0, 1.0);
        String key = parts[0];
        try {
            Double volume = Double.parseDouble(parts[1]);
            Double pitch = Double.parseDouble(parts[2]);
            return new Sound(key, volume, pitch);
        } catch(Exception e) {
            // On parsing failure, revert to defaults to keep behavior predictable
            return new Sound(string, 1.0, 1.0);
        }
    }
    
    @Override
    public String toString() {
        // Fields are guaranteed non-null, so print them all unconditionally.
        return "Sound{key=\"" + key + "\", volume=" + volume + ", pitch=" + pitch + "}";
    }
    
    /**
	 * Plays this sound at the specified location.
	 *
	 * @param location the location where the sound should be played
	 */
    @SuppressWarnings("deprecation")
	public void play(Location location) {
		location.getWorld().playSound(location, org.bukkit.Sound.valueOf(key), volume, pitch);
	}
    
    /**
     * Plays this sound to the specified player.
     * 
     * @param player the player where the sound should be played
     */
    @SuppressWarnings("deprecation")
	public void play(Player player) {
    	player.getWorld().playSound(player, org.bukkit.Sound.valueOf(key), volume, pitch);
	}
}