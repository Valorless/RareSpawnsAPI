package valorless.rarespawns.datamodels;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Spellcaster.Spell;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import valorless.valorlessutils.types.Vector2;

/**
 * Mutable data container representing a rare entity definition and its runtime state.
 * <p>
 * This structure is populated from configuration (and sometimes dynamically) and then
 * referenced while spawning, updating, running abilities, and handling lifecycle events
 * for rare entities. Unless otherwise stated collections are initialised (never null)
 * to simplify external iteration. Fields may remain null when absence is a meaningful
 * state (e.g., optional strings, numeric overrides, flags).
 * </p>
 * <p>
 * Runtime maps keyed by {@link LivingEntity} (e.g., {@link #runnables}, {@link #abilityRunnables},
 * {@link #bossbars}) track per-instance scheduler task ids or UI elements and should be
 * cleaned up on despawn/death to avoid leaks.
 * </p>
 */
public class EntityData {
	/** Internal init flag (currently unused). */
	private Boolean init = false; // Not currently in use

	/** Constructs a new data container marking it initialised. */
	public EntityData() {
		init = true;
	}

	/** Indicates the data object has been constructed (legacy placeholder). */
	public Boolean getInit() {
		return init;
	}

	/** Primary runnable task id per entity (e.g., main tick/update loop). */
	public HashMap<LivingEntity, Integer> runnables = new HashMap<LivingEntity, Integer>();
	/** Definition identifier (config id). */
	public String id;
	/** Active entity instances bound to this definition. */
	public List<LivingEntity> entities = new ArrayList<>();
	/** Spawn weight (used in random selection logic). */
	public Integer weight = 0;

	/**
	 * Optional spawn group membership and chance configuration.
	 * When set, ties this entity to a {@link SpawnGroup} which may influence
	 * selection/weighting in spawn logic.
	 */
	public SpawnGroup spawnGroup;

	// Conditions
	/** Whether to select a new rare entity if conditions not met. */
	public boolean selectNew = true;
	/** Biome names for spawn condition checking. */
	public List<String> biomes;
	/** Whether biome list is a blacklist (true) or whitelist (false). */
	public boolean biomeBlacklist = false;
	/** Weather condition for spawning (e.g., rain, clear). */
	public String weather;
	/** Time condition for spawning (e.g., day, night, or custom range i.e. '0-24000'). */
	public String time;
	/** Whether the entity can be spawned in water. */
	public Boolean inWater;
	/** Whether the entity should be in direct sky light (not under blocks). */
	public Boolean directSky;
	/** Minimum light level for spawning. */
	public Vector2<Integer> lightLevel;


	// Nameplate / Display
	/** Multi-line nameplate (raw lines with formatting tokens). */
	public List<String> name;
	/** Single custom name override (if provided) shown by Minecraft. */
	public String customName;
	/** Whether the custom name is always visible. */
	public Boolean customNameVisible;
	/** Whether rendered name text uses shadow. */
	public Boolean nameTextShadow;
	/** Maximum line width for wrapped name text. */
	public Integer nameLineWidth;
	/** Billboard mode for name (e.g., fixed, centered) if supported. */
	public String nameBillboard;
	/** Name scale multiplier. */
	public Double nameScale = 1.0;
	/** Whether a background panel is drawn behind name. */
	public Boolean nameBackgrond; // (typo maintained if used elsewhere)
	/** Background color (hex / named) for name panel. */
	public String nameBackgroundColor;
	/** Whether the name is visible through walls (see-through). */
	public Boolean nameSeeThrough;
	/** View distance (blocks) for name rendering. */
	public Integer nameViewDistance;
	/** Positional offset applied to the nameplate. */
	public Vector nameOffset;

	// Core stats / behavior
	/** Whether entity is considered hostile (affects AI/targeting logic). */
	public boolean hostile = false;
	/** Minecraft entity type to spawn. */
	public EntityType type;
	/** Optional extension type for custom entity systems (e.g., MythicMobs). */
	public String customType;
	/** Base health value. */
	public Integer health = 20;
	/** Base absorption value (extra hearts). */
	public Integer absorption;
	/** Persistent potion effects with amplifiers. */
	public HashMap<PotionEffectType, Integer> effects = new HashMap<PotionEffectType, Integer>();
	/** Inventory / equipment specification. */
	public InventoryData inventory = new InventoryData();
	/** Allow natural despawn flag. */
	public Boolean despawn = false;
	/** Enable anti-stuck logic (teleport/unstick). */
	public Boolean antiStuck = true;
	/** Attribute overrides (GENERIC_* etc.) mapped to values. */
	public HashMap<Attribute, Double> attributes = new HashMap<Attribute, Double>();
	/** Ability identifiers applied to this entity. */
	public List<String> abilities = new ArrayList<>();
	/** Scheduler task ids for ability per-entity periodic runnables. */
	public HashMap<LivingEntity, List<Integer>> abilityRunnables = new HashMap<LivingEntity, List<Integer>>();

	// Spawn message
	/** Lines broadcast to nearby players when spawned. */
	public List<String> spawnMessage = new ArrayList<>();
	/** Radius in blocks for spawn message distribution. */
	public Integer spawnMessageRadius = 100;
	/** Sound played on spawn announcement. */
	public Sound spawnMessageSound;

	// Death message
	/** Lines broadcast when entity dies. */
	public List<String> deathMessage = new ArrayList<>();
	/** Radius in blocks for death message distribution. */
	public Integer deathMessageRadius = 100;
	/** Sound played on death announcement. */
	public Sound deathMessageSound;

	// Drop table
	/** Whether the drop table uses real (natural) drop mechanics. */
	public Boolean dropTableReal = true;
	/** Drop table specification entries (id:chance, etc.). */
	public List<String> dropTable = new ArrayList<>();
	/** Whether to keep original drops. */
	public Boolean dropOriginal = false;

	// Boss bar
	/** Enable boss bar UI. */
	public Boolean bossbar;
	/** Boss bar displayed name. */
	public String bossbarName;
	/** Boss bar color. */
	public BarColor bossbarColor;
	/** Boss bar style (segments, solid). */
	public BarStyle bossbarStyle;
	/** Max render distance for boss bar. */
	public Integer bossbarDistance;
	/** Active boss bar handles per living entity. */
	public HashMap<LivingEntity, RareEntityBossBar> bossbars = new HashMap<LivingEntity, RareEntityBossBar>();

	// Misc state toggles
	/** AI enabled flag. */
	public Boolean ai = true;
	/** Arrow count visually in body. */
	public Integer arrowsInBody = 0;
	/** Ticks until arrows despawn. */
	public Integer arrowsDespawnTicks = 999999;
	/** Spawn as baby variant. */
	public Boolean baby = false;
	/** Can pick up dropped items. */
	public Boolean canPickUpItems = false;
	/** Is collidable with other entities. */
	public Boolean collidable = true;
	/** Currently gliding (elytra). */
	public Boolean gliding = false;
	/** Invisible flag. */
	public Boolean invisible = false;
	/** Remaining air supply (breath). */
	public Integer breath = 200;
	/** Remove when far from players (vanilla despawn). */
	public Boolean removeWhenFarAway = false;
	/** Currently performing riptide. */
	public Boolean riptiding = false;
	/** Swimming state. */
	public Boolean swimming = false;
	/** Passenger (entity id / config reference). */
	public String passenger;
	/** Passenger unique UUID reference. */
	public UUID passengerUUID;
	/** Accumulated fall distance. */
	public Double fallDistance = 3.0;
	/** Current fire ticks remaining. */
	public Integer fireTicks = 0;
	/** Whether entity visually on fire. */
	public Boolean onFire = false;
	/** Glowing outline flag. */
	public Boolean glowing = false;
	/** Gravity enabled flag. */
	public Boolean gravity = true;
	/** Can use portals. */
	public Boolean canUsePortals = false;
	/** Silent (no sounds) flag. */
	public Boolean silent = false;
	/** Visible by default to players (not requiring reveal). */
	public Boolean visibleByDefault = true;
	/** Slime size (for slime/magma cube). */
	public Integer slimeSize = 1;
	/** Whether slime splits on death. */
	public boolean slimeSplit = false;
	/** Wolf angry state. */
	public Boolean wolfAngry = false;
	/** Damage causes this entity is immune to. */
	public List<DamageCause> immuneTo = new ArrayList<>();
	/** Aggro acquisition range. */
	public double aggroRange = 20.0;
	/** Whether the entity can be leashed. */
	public Boolean leadable = true;
	/** Whether the entity can breed. */
	public Boolean breedable = false;

	// Taming configuration
	/** Whether vanilla taming logic applies. */
	public Boolean tameableVanilla;
	/** Required item key for taming. */
	public String tameableItem;
	/** Chance (0-100) of successful tame per attempt. */
	public Double tameableChance;
	/** Sound played on tame failure. */
	public Sound tameableSoundFail;
	/** Particle effect on tame failure. */
	public Particle tameableParticleFail;
	/** Particle count on tame failure. */
	public Integer tameableParticleAmountFail;
	/** Sound played on successful tame. */
	public Sound tameableSoundTame;
	/** Particle effect on tame success. */
	public Particle tameableParticleTame;
	/** Particle count on tame success. */
	public Integer tameableParticleAmountTame;

	// Variant data (species-specific)
	/** Wolf variant/type id. */
	public String wolfType;
	/** Cat variant/type id. */
	public String catType;
	/** Horse base color. */
	public String horseColor;
	/** Horse style (markings). */
	public String horseStyle;
	/** Horse armor. */
	public String horseArmor;
	/** Parrot variant. */
	public String parrotType;
	/** Rabbit variant. */
	public String rabbitType;
	/** Axolotl variant. */
	public String axolotlType;
	/** Tropical fish body color. */
	public String tropicalColor;
	/** Tropical fish pattern id. */
	public String tropicalPattern;
	/** Tropical fish pattern color. */
	public String tropicalPatternColor;
	/** Panda main gene. */
	public String pandaMainGene;
	/** Panda hidden gene. */
	public String pandaHiddenGene;

	// Spellcaster
	/** List of spell types this entity can cast. */
	public List<Spell> spells = new ArrayList<Spell>();

	/** Invulnerability frames after taking damage (ticks). */
	public Integer iframes = 20;

	/** Spawn this entity with other entities. They will spawn at the same time and location. */
	public List<String> groupSpawn = new ArrayList<>();
}