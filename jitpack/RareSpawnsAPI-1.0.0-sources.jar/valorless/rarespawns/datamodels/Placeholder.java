package valorless.rarespawns.datamodels;

/**
 * Represents a placeholder key-value pair for dynamic text replacement in RareSpawns.
 * Used for substituting variables in messages, lore, or other text fields.
 */
public class Placeholder {
	/**
	 * The placeholder key (e.g., %player%, %mob%, etc.).
	 */
	public String key;
	/**
	 * The value to substitute for the placeholder key.
	 */
	public String value;
	
	/**
	 * Constructs a Placeholder with the given key and value.
	 * @param key The placeholder key.
	 * @param value The value to substitute (converted to String).
	 */
	public Placeholder(String key, Object value) {
		this.key = key;
		this.value = String.valueOf(value);
	}

}