/**
 * Data models backing configuration and runtime state.
 * Includes item/entity definitions and simple DTOs used across the plugin.
 */
package valorless.rarespawns.datamodels;