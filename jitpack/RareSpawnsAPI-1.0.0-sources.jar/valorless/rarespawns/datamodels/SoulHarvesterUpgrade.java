package valorless.rarespawns.datamodels;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import org.bukkit.inventory.EquipmentSlotGroup;

import valorless.rarespawns.Lang;
import valorless.rarespawns.Main;
import valorless.rarespawns.enums.SoulHarvesterUpgradeType;
import valorless.rarespawns.persistentdatacontainer.PDC;
import valorless.rarespawns.utils.AttributeUtils;
import valorless.rarespawns.utils.SFX;
import valorless.rarespawns.utils.Utils;
import valorless.valorlessutils.ValorlessUtils.Log;
import valorless.valorlessutils.items.ItemUtils;

/**
 * Data model describing a single Soul Harvester upgrade step.
 * <p>
 * An upgrade can modify item attributes, add enchantments, or grant a Soul Power
 * once its conditions are met. Conditions include a souls requirement, optional
 * entity type filter, and chance to apply. When successfully applied, a unique
 * tag is written to the item's PersistentDataContainer to prevent duplicates.
 * </p>
 * <p>
 * Namespacing: each upgrade is addressed via a unique key composed of the owning
 * item id and a UUID. Use {@link #getNamespacedId()} or {@link #getNamespacedKey()}.
 * </p>
 */
public class SoulHarvesterUpgrade {
	
	/** The internal id (filename stem) assigned after load.
	 *  id of the item this upgrade belongs to, used for namespacing.
	 */
	private final String id;
	
	/** Unique uuid for this upgrade instance, used for namespacing.
	 * If missing from the config, generate a random one on load.
	 */
	private final String uuid;
	
	/**
	 * Unique namespaced id for this upgrade instance.
	 *
	 * @return a stable namespaced id in the form SHU-<itemId>_<uuid>
	 */
	public String getNamespacedId() {
		return String.format("SHU-%s_%s", id, uuid);
	}
	
	/**
	 * Unique namespaced key for this upgrade instance, scoped to the plugin.
	 *
	 * @return a NamespacedKey that can be used with PersistentDataContainer
	 */
	public NamespacedKey getNamespacedKey() {
		return new NamespacedKey(Main.plugin, String.format("SHU-%s_%s", id, uuid));
	}

	// Common
	/** Type of upgrade: ATTRIBUTE, ENCHANTMENT, POWER, MODELDATA, ITEMMODEL */
	public SoulHarvesterUpgradeType type = null;
	/** Number of souls required to unlock this upgrade */
	public Integer requiredSouls = 1;
	/** Specific entity type required to unlock this upgrade, or null for any */
	public String entityType = null;
	/** Chance (0.0 - 100.0) that this upgrade will be applied when conditions are met */
	public Double chance = 100.0;
	/** Sound to play when this upgrade is unlocked, or null for none */
	public Sound unlockSound = null;
	/** Particle effect to play when this upgrade is unlocked, or null for none */
	public Particle unlockParticle = null;
	
	// Item Name Upgrade
	/** Item name to set on the item */
	public String itemName = null;
	
	// Display Name Upgrade
	/** Display name to set on the item */
	public String displayName = null;
	
	// Lore Upgrade
	/** Lore lines to set on the item */
	public List<String> lore = null;
	
	// Lore Add Upgrade
	/** Lore lines to add to existing item lore */
	public List<String> loreAdd = null;
	
	// Attribute Upgrade
	/** Attribute to modify: GENERIC_ATTACK_DAMAGE, GENERIC_MOVEMENT_SPEED, etc. */
	public Attribute attribute = null;
	/** Amount to modify the attribute by */
	public Double attributeAmount = 0.0;
	/** Operation to apply the attribute modifier to */
	public AttributeModifier.Operation attributeOperation = Operation.ADD_NUMBER; // ADD_NUMBER, ADD_SCALAR, MULTIPLY_SCALAR_1
	/** Equipment slot to apply the attribute modifier to */
	public EquipmentSlotGroup attributeSlot = EquipmentSlotGroup.MAINHAND; // MAINHAND, OFFHAND, HEAD, CHEST, LEGS, FEET
	
	// Enchantment Upgrade
	/** Enchantment to apply: SHARPNESS, FIRE_ASPECT, etc. */
	public String enchantment = null;
	/** Level of the enchantment to apply */
	public Integer enchantmentLevel = 1;
	/** Whether to override enchantment levels that are higher than this upgrade */
	public Boolean enchantmentOverride = false;
	
	// Power Upgrade
	/** Soul Power to apply: custom power defined in SoulPower class */
	public String soulPower = null;
	
	// Custom Model Data Upgrade
	/** Custom model data value to set on the item */
	public Integer customModelData = null;
	
	// Item Model Upgrade
	/** Item model to set on the item */
	public String itemModel = null;
	
	/**
	 * Creates a SoulHarvesterUpgrade from raw string type.
	 *
	 * @param id            item id this upgrade belongs to (used for namespacing)
	 * @param uuid          unique identifier for this upgrade instance
	 * @param type          upgrade type name (ATTRIBUTE, ENCHANTMENT, POWER, MODELDATA, etc.)
	 * @param requiredSouls souls required to unlock/apply this upgrade
	 * @throws IllegalArgumentException if type is invalid
	 */
	public SoulHarvesterUpgrade(String id, String uuid, String type, Integer requiredSouls) {
		this.id = id;
		this.uuid = uuid;
		this.type = SoulHarvesterUpgradeType.fromString(type);
		if(this.type == null) {
			throw new IllegalArgumentException(String.format("Soul Harvester upgrade '%s-%s' has invalid type '%s'.", id, uuid, type));
		}
		this.requiredSouls = requiredSouls;
	}
	
	/**
	 * Creates a SoulHarvesterUpgrade with a resolved enum type.
	 *
	 * @param id            item id this upgrade belongs to (used for namespacing)
	 * @param uuid          unique identifier for this upgrade instance
	 * @param type          upgrade type (ATTRIBUTE, ENCHANTMENT, POWER, MODELDATA, etc.)
	 * @param requiredSouls souls required to unlock/apply this upgrade
	 * @throws IllegalArgumentException if type is null
	 */
	public SoulHarvesterUpgrade(String id, String uuid, SoulHarvesterUpgradeType type, Integer requiredSouls) {
		this.id = id;
		this.uuid = uuid;
		this.type = type;
		if(type == null) {
			throw new IllegalArgumentException(String.format("Soul Harvester upgrade '%s-%s' type cannot be null!", id, uuid));
		}
		this.requiredSouls = requiredSouls;
	}
	
	@SuppressWarnings("deprecation")
	public Boolean applyUpgrade(ItemStack item, Player player) {
		List<String> appliedUpgrades = appliedUpgrades(item);
		if(isApplied(appliedUpgrades)) {
			return false;
		}
		if(!Utils.Chance(chance)) {
			return false;
		}
		
		Integer souls = PDC.has(item, "souls") ? PDC.getInteger(item, "souls") : 0;
		if(souls < requiredSouls) {
			return false;
		}
		
		ItemMeta meta = item.getItemMeta();
		if(type == SoulHarvesterUpgradeType.ATTRIBUTE) {
			AttributeModifier modifier = new AttributeModifier(getNamespacedKey(), attributeAmount, attributeOperation, attributeSlot);
			meta = AttributeUtils.addOrReplaceAttributeModifier(meta, attribute, modifier);
		}
		else if(type == SoulHarvesterUpgradeType.ENCHANTMENT) {
	        if(enchantment != null && enchantmentLevel > 0) {
	            try {
	                for (Enchantment enchant : Registry.ENCHANTMENT) {
	                    if(enchant.getKey().getKey().equalsIgnoreCase(enchantment)
	                        || enchant.getKey().getNamespace().equalsIgnoreCase(enchantment)
	                        || enchant.toString().equalsIgnoreCase(enchantment)
	                        || enchant.getName().equalsIgnoreCase(enchantment)) {

	                    	if(enchantmentOverride) {
	                            // Override existing level unconditionally
	                            meta.addEnchant(enchant, enchantmentLevel, true);
	                            break;
	                        }
	                    	
	                        // Check existing level and skip if existing level is >= new level
	                        int existingLevel = meta.hasEnchant(enchant) ? meta.getEnchantLevel(enchant) : 0;
	                        if (existingLevel >= enchantmentLevel) {
	                            break;
	                        }

	                        // Existing level is lower (or absent) -> apply the upgrade
	                        meta.addEnchant(enchant, enchantmentLevel, true);
	                        break;
	                    }
	                }
	            } catch(Exception e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    else if(type == SoulHarvesterUpgradeType.MODELDATA) {
	    	if(customModelData != null) {
	    		meta.setCustomModelData(customModelData);
	    	}
	    }
	    else if(type == SoulHarvesterUpgradeType.ITEMNAME) {
	    	meta.setItemName(Lang.parse(itemName, player));
	    }
	    else if(type == SoulHarvesterUpgradeType.DISPLAYNAME) {
	    	meta.setDisplayName(Lang.parse(displayName, player));
	    }
	    else if(type == SoulHarvesterUpgradeType.LORE) {
	    	List<String> parsedLore = new ArrayList<>();
	    	for(String line : lore) {
	    		parsedLore.add(Lang.parse(line, player));
	    	}
	    	meta.setLore(parsedLore);
	    }
	    else if(type == SoulHarvesterUpgradeType.LOREADD) {
	    	List<String> existingLore = meta.hasLore() ? meta.getLore() : new ArrayList<String>();
	    	for(String line : loreAdd) {
	    		existingLore.add(Lang.parse(line, player));
	    	}
	    	meta.setLore(existingLore);
	    }
		
		item.setItemMeta(meta);
		
		// Applied after meta changes to avoid overwriting.
		if(type == SoulHarvesterUpgradeType.POWER) {
			PDC.setBoolean(item, soulPower, true);
	    }
	    else if(type == SoulHarvesterUpgradeType.ITEMMODEL) {
	    	if(itemModel != null) {
	    		if(!itemModel.contains(":")) {
	    			Log.Error(Main.plugin, String.format("Soul Harvester upgrade '%s' has invalid item model '%s'. Must be in namespace:id format.", 
	    					getNamespacedId(), itemModel));
	    			
	    		}else {
	    			ItemUtils.SetItemModel(item, itemModel);
	    		}
	    	}
	    }
		
		appliedUpgrades.add(String.valueOf(uuid));
		PDC.setStringList(item, "upgrades", appliedUpgrades);
		
		//PDC.SetBoolean(item, getNamespacedId(), true);
		if(unlockSound != null && player != null) SFX.Play(unlockSound, player);
		if(unlockParticle != null && player != null) unlockParticle.spawn(player);
		Log.Debug(Main.plugin, String.format("Applied Soul Harvester upgrade '%s' to item for player %s.", 
				getNamespacedId(), (player != null ? player.getName() : "null")));
		
		//PrintItemStackTooltipFile.printToPluginFolder(item, Main.plugin);
		return true;
	}
	
	public List<String> appliedUpgrades(ItemStack item){
		return PDC.has(item, "upgrades") ?
				PDC.getStringList(item, "upgrades") : new ArrayList<String>();
	}
	
	public Boolean isApplied(List<String> appliedUpgrades) {
		for(Object entry : appliedUpgrades) {
			String upg = String.valueOf(entry);
			if(!(upg instanceof String)) {
				Log.Error(Main.plugin, "Soul Harvester upgrade UUID '" + uuid + "' on item '" + id +"' is not valid! This could indicate a data corruption issue on the item.");
				continue;
			}
			if(upg.equalsIgnoreCase(uuid)) {
				return true;
			}
		}
		return false;
	}
	
	public String toStringShort() {
		return String.format("SoulHarvesterUpgrade{id=%s, uuid=%s, type=%s, requiredSouls=%d}", 
				id, uuid, type != null ? type.toString() : "null", requiredSouls != null ? requiredSouls : 0);
	}
	
	
	@Override
	public String toString() {
	    StringBuilder sb = new StringBuilder();
	    sb.append("SoulHarvesterUpgrade{");
	    boolean first = true;

	    if (id != null) {
	        sb.append("id=").append(id);
	        first = false;
	    }
	    if (uuid != null) {
	        if (!first) sb.append(", ");
	        sb.append("uuid=").append(uuid);
	        first = false;
	    }

	    if (type != null) {
	        if (!first) sb.append(", ");
	        sb.append("type=").append(type.toString());
	        first = false;
	    }
	    if (requiredSouls != null) {
	        if (!first) sb.append(", ");
	        sb.append("requiredSouls=").append(requiredSouls);
	        first = false;
	    }
	    if (entityType != null) {
	        if (!first) sb.append(", ");
	        sb.append("entityType=").append(entityType);
	        first = false;
	    }
	    if (chance != null) {
	        if (!first) sb.append(", ");
	        sb.append("chance=").append(chance);
	        first = false;
	    }
	    if (unlockSound != null) {
	        if (!first) sb.append(", ");
	        sb.append("unlockSound=").append(unlockSound.toString());
	        first = false;
	    }

	    if (attribute != null) {
	        if (!first) sb.append(", ");
	        sb.append("attribute=").append(attribute);
	        first = false;
	    }
	    if (attributeAmount != null) {
	        if (!first) sb.append(", ");
	        sb.append("attributeAmount=").append(attributeAmount);
	        first = false;
	    }
	    if (attributeOperation != null) {
	        if (!first) sb.append(", ");
	        sb.append("attributeOperation=").append(attributeOperation);
	        first = false;
	    }
	    if (attributeSlot != null) {
	        if (!first) sb.append(", ");
	        sb.append("attributeSlot=").append(attributeSlot);
	        first = false;
	    }

	    if (enchantment != null) {
	        if (!first) sb.append(", ");
	        sb.append("enchantment=").append(enchantment);
	        first = false;
	    }
	    if (enchantmentLevel != null) {
	        if (!first) sb.append(", ");
	        sb.append("enchantmentLevel=").append(enchantmentLevel);
	        first = false;
	    }

	    if (soulPower != null) {
	        if (!first) sb.append(", ");
	        sb.append("soulPower=").append(soulPower);
	        first = false;
	    }
	    if (customModelData != null) {
	        if (!first) sb.append(", ");
	        sb.append("customModelData=").append(customModelData);
	        first = false;
	    }
	    if (itemModel != null) {
	        if (!first) sb.append(", ");
	        sb.append("itemModel=").append(itemModel);
	        first = false;
	    }
	    if (itemName != null) {
	        if (!first) sb.append(", ");
	        sb.append("itemName=").append(itemName);
	        first = false;
	    }
	    if (displayName != null) {
	        if (!first) sb.append(", ");
	        sb.append("displayName=").append(displayName);
	        first = false;
	    }
	    if (lore != null) {
	        if (!first) sb.append(", ");
	        sb.append("lore=").append(lore);
	    }
	    if (loreAdd != null) {
	        if (!first) sb.append(", ");
	        sb.append("loreAdd=").append(loreAdd);
	    }

	    sb.append('}');
	    return sb.toString();
	}
}