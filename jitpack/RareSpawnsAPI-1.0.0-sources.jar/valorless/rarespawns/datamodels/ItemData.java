package valorless.rarespawns.datamodels;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.components.FoodComponent;
import org.bukkit.inventory.meta.components.JukeboxPlayableComponent;
import org.bukkit.inventory.meta.components.ToolComponent;

import valorless.rarespawns.builders.components.Consumable;
import valorless.rarespawns.builders.components.Cooldown;
import valorless.rarespawns.builders.components.Equippable;
import valorless.rarespawns.builders.components.PowerItemComponent;
import valorless.rarespawns.builders.components.SoulHarvesterComponent;
import valorless.valorlessutils.config.Config;

/**
 * Immutable data container describing a RareSpawns item definition parsed from its YAML file.
 * <p>
 * Each public field corresponds (loosely) to a configuration key or group of keys. The builder
 * layer (ItemBuilder / ItemCreator) reads these values to construct a runtime {@link ItemStack}.
 * </p><p>
 * This object is not intended to be mutated after construction; most collections are created
 * eagerly (never null) to simplify downstream code. Absent/disabled features remain null where
 * distinction from an empty collection is meaningful (e.g., {@code customModelData}).
 * </p><p>
 * The {@link #update} flag indicates whether existing in-game items referencing this definition
 * are eligible for automatic rebuild via updateItem logic.
 * </p>
 */
public class ItemData {

	/** Underlying loaded configuration (for advanced inspection / debugging). */
	public final Config config;
	/** Whether updateItem should rebuild instances of this item (config key: update-item). */
	public final boolean update;
	/** The internal id (filename stem) assigned after load. */
	public final String id;

	// Core identity / presentation
	/** Raw internal name (item-name). */
	public String itemName;
	/** Display name shown to players (display-name). */
	public String displayName;
	/** Localised / parsed lore lines (lore). Never null. */
	public List<String> lore = new ArrayList<>();
	/** Base material (material). */
	public Material material;
	/** Stack amount (amount). */
	public Integer amount = 1;
	/** Max stack size override (max-stack). */
	public Integer maxStack;
	/** Custom model data (model-data). */
	public Integer customModelData;
	/** Custom item model (item-model). */
	public String itemModel;
	/** Max durability override (durability). */
	public Integer durability;
	/** Already consumed durability / damage value (missing-durability). */
	public Integer missingDurability;
	/** Unbreakable flag (unbreakable). */
	public Boolean unbreakable = false;
	/** Hide vanilla tooltip (hide-tooltip). */
	public Boolean hideTooltip = false;
	/** Rarity (rarity). */
	public String rarity;
	/** Enchantments (enchants). Never null. */
	public HashMap<Enchantment, Integer> enchants = new HashMap<Enchantment, Integer>();
	/** Attribute modifiers (attributes). Never null. */
	public HashMap<Attribute, AttributeModifier> attributes = new HashMap<Attribute, AttributeModifier>();
	/** Item flags (item-flags). Never null. */
	public List<ItemFlag> itemFlags = new ArrayList<ItemFlag>();
	/** NBT values to inject (nbt). Never null. */
	public HashMap<String, NBTData> nbt = new HashMap<String, NBTData>();
	/** Custom tags (tags). Never null. */
	public HashMap<NamespacedKey, TagData> tags = new HashMap<NamespacedKey, TagData>();

	// Components / advanced meta
	/** Food component (food.*). */
	public FoodComponent food;
	/** 1.21.4+ consumable behaviour component (food.* mapped). */
	public io.papermc.paper.datacomponent.item.Consumable consumable;
	/** Sound when consumption completes (food.sound-done). */
	public Sound consumeSound;
	/** Tool component (tool.*). */
	public ToolComponent tool;
	/** Jukebox playable component (playable.*). */
	public JukeboxPlayableComponent playable;
	/** Use cooldown component (use-cooldown.*). */
	public Cooldown useCooldown;
	/** Equippable component (equippable.*). */
	public Equippable equippable;
	/** Glider flag (equippable.glider). */
	public Boolean glider;
	/** Remainder item after use (use-remainder). */
	public ItemStack useRemainder;
	/** Power item component (poweritem.*). */
	public PowerItemComponent powerItem;
	/** Soul Harvester component (soul-harvester.*). */
	public SoulHarvesterComponent soulHarvester;

	// Cosmetic extras
	/** Base64 head texture (head-texture). */
	public String headTexture;
	/** Armor trim pattern (trim.pattern). */
	public String trimPattern;
	/** Armor trim material (trim.material). */
	public String trimMaterial;
	/** Hex dyed color (dyed). */
	public String dyedColor;
	/** Banner patterns (banner-patterns). Never null. */
	public List<String> bannerPatterns = new ArrayList<>();
	/** Potion effects (potion-effects). Never null. */
	public List<String> potionEffects = new ArrayList<>();
	/** Stored book enchantments (stored-enchantments). Never null. */
	public List<String> storedEnchants = new ArrayList<>();
	/** Tooltip style key (tooltip-style). */
	public String tooltipStyle;

	/** Soulbound flag (soulbound). */
	public Boolean soulbound = false;

	// Knowledge book / written book
	/** Knowledge book recipe key (knowledge-book). */
	public String knowledgeBook;
	/** Written book content (written-book.*). */
	public WrittenBook book;

	// Egg
	/** Hatch flag (egg.hatch). */
	public Boolean hatch = false;
	/** Entity type to hatch (egg.type). */
	public String hatchType;
	/** Number of entities to hatch (egg.amount). */
	public Integer hatchAmount;
	/** Sound to play on egg throw (egg.sound). */
	public Sound eggSound;

	// Drops Multiplier
	/** Multiplier for items from crops (drops-multiplier.crops). */
	public Double cropsMultiplier;
	/** Multiplier for items obtained via harvesting (drops-multiplier.harvested). */
	public Double harvestedMultiplier;
	/** Shear multiplier for items obtained via shearing (drops-multiplier.shearing). */
	public Double shearMultiplier;

	// Spawner settings
	/** Entity type the spawner will produce (spawner.type). */
	public String spawnerType;
	/** Number of entities spawned per cycle (spawner.spawn-count). */
	public Integer spawnerSpawnCount;
	/** Current / initial spawner delay in ticks (spawner.delay). */
	public Integer spawnerDelay;
	/** Minimum delay between spawn cycles in ticks (spawner.min-spawn-delay). */
	public Integer spawnerMinDelay;
	/** Maximum delay between spawn cycles in ticks (spawner.max-spawn-delay). */
	public Integer spawnerMaxDelay;
	/** Maximum nearby entities before spawning pauses (spawner.max-nearby-entities). */
	public Integer spawnerMaxNearbyEntities;

	// Sounds
	/** Sound to play when the item is picked up (sounds.pickup). */
	public Sound pickupSound;
	/** Sound to play when the item is dropped (sounds.drop). */
	public Sound dropSound;
	/** Sound to play when the item is broken (sounds.break). */
	public Sound breakSound;

	// Fishing behaviour overrides
	/** Experience dropped when caught via fishing (fishing.exp-drop). */
	public Integer fishingExp;
	/** Apply lure effect when fishing with this item (fishing.apply-lure). */
	public Boolean fishingLure;
	/** Minimum lure angle (degrees) for hook spread (fishing.lure-angle.min). */
	public Integer fishingLureAngleMin;
	/** Maximum lure angle (degrees) for hook spread (fishing.lure-angle.max). */
	public Integer fishingLureAngleMax;
	/** Minimum lure time in ticks (fishing.lure-time.min). */
	public Integer fishingLureTimeMin;
	/** Maximum lure time in ticks (fishing.lure-time.max). */
	public Integer fishingLureTimeMax;
	/** Minimum wait time before a bite in ticks (fishing.wait-time.min). */
	public Integer fishingWaitTimeMin;
	/** Maximum wait time before a bite in ticks (fishing.wait-time.max). */
	public Integer fishingWaitTimeMax;
	/** Whether rain influences catch timing (fishing.rain-influenced). */
	public Boolean fishingRainInfluenced;
	/** Whether open sky influences catch timing (fishing.sky-influenced). */
	public Boolean fishingSkyInfluenced;
	/** Sound when casting the line (fishing.sound-cast). */
	public Sound fishingSoundCast;
	/** Sound when a fish bites (fishing.sound-bite). */
	public Sound fishingSoundBite;
	/** Sound when a catch is collected (fishing.sound-caught). */
	public Sound fishingSoundCaught;

	/** When true, this item functions as a totem of resurrection (totem.resurrect). */
	public Boolean totem = false;
	/** When true, the totem must be in the player's main or off hand to function (totem.held). */
	public Boolean totemHeld = false;
	/** Optional sound to play when the totem triggers (totem.sound). */
	public Sound totemSound;

	/** When set, this item functions as a "soulstone" that can spawn entities (soulstone.entity). */
	public String soulstone;
	/** Sound played when the soulstone is used (soulstone.sound). */
	public Sound soulstoneSound;


	/**
	 * Constructs the data model from a loaded configuration. Only the update flag is
	 * interpreted here; all other fields are populated later by the builder pipeline.
	 *
	 * @param config source configuration file wrapper
	 */
	public ItemData(Config config, String id) {
		this.config = config;
		this.id = id;
		this.update = config.hasKey("update-item") ? config.getBool("update-item") : false;
	}

}