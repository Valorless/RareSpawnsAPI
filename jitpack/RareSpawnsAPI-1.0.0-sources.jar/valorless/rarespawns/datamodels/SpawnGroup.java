package valorless.rarespawns.datamodels;

import java.util.List;

import valorless.rarespawns.Main;
import valorless.rarespawns.builders.EntityCreator;
import valorless.valorlessutils.ValorlessUtils.Log;

/**
 * Represents a spawn group used by the RareSpawns plugin.
 * <p>
 * A spawn group bundles a unique identifier and a base chance used by the
 * selection logic. In addition to the immutable identifier and chance,
 * the instance exposes a set of optional, mutable properties that control
 * how entities are spawned (e.g., range limits, blacklist, shared drops).
 * <p>
 * The constructor seeds these properties from the plugin's global configuration
 * so the object starts with sensible defaults that can be overridden per group
 * by calling the provided setters.
 */
public class SpawnGroup {
	
	/**
	 * Creates a fallback SpawnGroup when configuration is invalid.
	 * <p>
	 * An error is logged and a default group (as provided by
	 * {@link EntityCreator#getSpawnGroup(String) EntityCreator.getSpawnGroup("default")})
	 * is returned.
	 *
	 * @param message message describing why a fallback was required (logged as an error)
	 * @return a default SpawnGroup instance
	 */
	public static SpawnGroup InvalidSpawnGroup(String message) {
		Log.Error(Main.plugin, message);
		return EntityCreator.getSpawnGroup("default");
	}
	
	/** Unique identifier for this spawn group (e.g., a config section name). */
	private final String groupId;
	/**
	 * Base chance used when evaluating this group during selection. The exact
	 * semantics (percentage, weight, etc.) are defined by the consuming logic.
	 */
	private final int spawnChance;
	/** Whether to log spawns for this group. */
	private Boolean logSpawns = true;
	/** Whether to log deaths for this group. */
	private Boolean logDeaths = true;
	/** Whether spawns teleport above ground. */
	private Boolean aboveGround = null;
	/** Maximum horizontal spawn range in blocks. */
	private Integer spawnRangeMax = null;
	/** Maximum number of spawns allowed within the limit range. */
	private Integer spawnLimitAmount = null;
	/** Range in blocks over which the spawn limit is evaluated. */
	private Integer spawnLimitRange = null;
	/** Whether to show fireworks on spawn. */
	private Boolean fireworks = null;
	/** World identifiers where spawning is blocked. */
	private List<String> blacklist = null;
	/** Shared drop table names to apply to spawned entities. */
	private List<String> sharedDrops = null;

	/**
	 * Constructs a SpawnGroup with the given identifier and base chance.
	 * <p>
	 * All optional fields are initialized from the plugin's global configuration
	 * as starting defaults and may later be overridden via setters.
	 *
	 * @param groupId     non-null unique group identifier
	 * @param spawnChance base chance associated with this group
	 */
	public SpawnGroup(String groupId, int spawnChance) {
		this.groupId = groupId;
		this.spawnChance = spawnChance;
		setAboveGround(Main.config.GetBool("spawn-above-ground"));
		setSpawnRangeMax(Main.config.GetInt("spawn-range-max"));
		setSpawnLimitAmount(Main.config.GetInt("spawn-limit.amount"));
		setSpawnLimitRange(Main.config.GetInt("spawn-limit.range"));
		setFireworks(Main.config.GetBool("spawn-firework.enabled"));
		setBlacklist(Main.config.GetStringList("blacklist"));
		setSharedDrops(Main.config.GetStringList("shared-drops"));
	}

	/**
	 * Returns the unique identifier for this group.
	 *
	 * @return the group identifier (never null)
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * Returns the base chance value associated with this group.
	 *
	 * @return the chance value
	 */
	public int getSpawnChance() {
		return spawnChance;
	}
	
	/**
	 * Whether to log spawns for this group.
	 *
	 * @return true/false if explicitly set.
	 */
	public Boolean getLogSpawns() {
		return logSpawns;
	}

	/**
	 * Sets whether to log spawns for this group.
	 *
	 * @param logSpawns true/false to override.
	 */
	public void setLogSpawns(Boolean logSpawns) {
		this.logSpawns = logSpawns;
	}

	/**
	 * Whether to log deaths for this group.
	 *
	 * @return true/false if explicitly set.
	 */
	public Boolean getLogDeaths() {
		return logDeaths;
	}

	/**
	 * Sets whether to log deaths for this group.
	 *
	 * @param logDeaths true/false to override.
	 */
	public void setLogDeaths(Boolean logDeaths) {
		this.logDeaths = logDeaths;
	}

	/**
	 * Whether spawns teleports above ground.
	 *
	 * @return true/false if explicitly set.
	 */
	public Boolean getAboveGround() {
		return aboveGround;
	}

	/**
	 * Sets whether spawns teleports above ground.
	 *
	 * @param aboveGround true/false to override.
	 */
	public void setAboveGround(Boolean aboveGround) {
		this.aboveGround = aboveGround;
	}

	/**
	 * Maximum horizontal spawn range in blocks.
	 *
	 * @return max range.
	 */
	public Integer getSpawnRangeMax() {
		return spawnRangeMax;
	}

	/**
	 * Sets the maximum horizontal spawn range in blocks.
	 *
	 * @param spawnRangeMax max range in blocks.
	 */
	public void setSpawnRangeMax(Integer spawnRangeMax) {
		this.spawnRangeMax = spawnRangeMax;
	}

	/**
	 * Per-range spawn limit amount.
	 *
	 * @return limit amount.
	 */
	public Integer getSpawnLimitAmount() {
		return spawnLimitAmount;
	}

	/**
	 * Sets the per-range spawn limit amount.
	 *
	 * @param spawnLimitAmount amount.
	 */
	public void setSpawnLimitAmount(Integer spawnLimitAmount) {
		this.spawnLimitAmount = spawnLimitAmount;
	}

	/**
	 * Range in blocks over which the spawn limit is evaluated.
	 *
	 * @return limit range in blocks.
	 */
	public Integer getSpawnLimitRange() {
		return spawnLimitRange;
	}

	/**
	 * Sets the range in blocks over which the spawn limit is evaluated.
	 *
	 * @param spawnLimitRange range in blocks.
	 */
	public void setSpawnLimitRange(Integer spawnLimitRange) {
		this.spawnLimitRange = spawnLimitRange;
	}

	/**
	 * Whether to show fireworks on spawn.
	 *
	 * @return true/false if explicitly set.
	 */
	public Boolean getFireworks() {
		return fireworks;
	}

	/**
	 * Sets whether to show fireworks on spawn.
	 *
	 * @param fireworks true/false to override.
	 */
	public void setFireworks(Boolean fireworks) {
		this.fireworks = fireworks;
	}

	/**
	 * List of world or biome identifiers that should not spawn entities for this group.
	 *
	 * @return blacklist, possibly empty.
	 */
	public List<String> getBlacklist() {
		return blacklist;
	}

	/**
	 * Sets the blacklist for this group.
	 *
	 * @param blacklist list of identifiers.
	 */
	public void setBlacklist(List<String> blacklist) {
		this.blacklist = blacklist;
	}

	/**
	 * Names of shared drop tables to apply.
	 *
	 * @return list of shared drop table names.
	 */
	public List<String> getSharedDrops() {
		return sharedDrops;
	}

	/**
	 * Sets the shared drop tables to apply to entities spawned by this group.
	 *
	 * @param sharedDrops list of table names.
	 */
	public void setSharedDrops(List<String> sharedDrops) {
		this.sharedDrops = sharedDrops;
	}

	/**
	 * Returns a diagnostic string including all group properties for logging/debugging.
	 * <p>
	 * The representation includes: groupId, spawnChance, aboveGround, spawnRangeMax,
	 * spawnLimitAmount, spawnLimitRange, fireworks, blacklist, and sharedDrops.
	 *
	 * @return a string like
	 * "SpawnGroup{id='groupId', chance=10, aboveGround=true, spawnRangeMax=64, spawnLimitAmount=5, spawnLimitRange=32, fireworks=false, blacklist=[world_nether], sharedDrops=[DIRT:5, DIAMOND:1:40]}"
	 */
	@Override
	public String toString() {
		return "SpawnGroup{id='" + groupId + "', chance=" + spawnChance
				+ ", aboveGround=" + aboveGround
				+ ", spawnRangeMax=" + spawnRangeMax
				+ ", spawnLimitAmount=" + spawnLimitAmount
				+ ", spawnLimitRange=" + spawnLimitRange
				+ ", fireworks=" + fireworks
				+ ", blacklist=" + blacklist
				+ ", sharedDrops=" + sharedDrops
				+ "}";
	}
}