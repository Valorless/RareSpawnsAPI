package valorless.rarespawns.datamodels;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import valorless.rarespawns.Main;
import valorless.valorlessutils.ValorlessUtils.Log;

/**
 * Data model describing a particle spawn configuration.
 * <p>
 * Encapsulates the particle key and basic spawn parameters: count, offset and extra.
 * A convenience {@link #parse(String)} method can construct an instance from a
 * compact string format.
 * </p>
 */
public class Particle {

    /**
     * Namespaced key or identifier of the particle to spawn (e.g. "FLAME").
     */
    public org.bukkit.Particle key;
    /**
     * Number of particle instances to spawn per call.
     */
    public Integer count;
    /**
     * Offset applied to X/Y/Z when spawning, used as spread.
     */
    public Double offset;
    /**
     * Extra/speed parameter passed to the particle system.
     */
    public Double extra;
    
    /**
     * Creates a particle configuration with explicit parameters.
     *
     * @param key    particle identifier (e.g., Bukkit particle key or name)
     * @param count  number of particles to spawn
     * @param offset positional spread on each axis
     * @param extra  extra/speed value for the particle
     */
    public Particle(String key, Integer count, Double offset, Double extra) {
    	try {
    		this.key = org.bukkit.Particle.valueOf(key);
    	} catch(Exception e) {
			Log.Error(Main.plugin, "Invalid particle key: " + key + ". Defaulting to REVERSE_PORTAL.");
			this.key = org.bukkit.Particle.REVERSE_PORTAL;
    	}
        this.count = count;
        this.offset = offset;
        this.extra = extra;
    }
    
    /**
     * Parses a particle specification string into a Particle instance.
     * <p>
     * Format: {@code key[:count[:offset[:extra]]]}
     * <ul>
     *   <li>key: required particle identifier</li>
     *   <li>count: integer (default 20)</li>
     *   <li>offset: double spread for x/y/z (default 0.5)</li>
     *   <li>extra: double extra/speed parameter (default 0.02)</li>
     * </ul>
     * Invalid numeric fields fall back to their defaults and log an error.
     * </p>
     *
     * @param string the particle specification string
     * @return a Particle instance with parsed or defaulted values
     */
    public static Particle parse(String string) {
        Integer count = 20;
        Double offset = 0.5;
        Double extra = 0.02;
        if(!string.contains(":")) return new Particle(string, 20, 0.5, 0.02);
        String[] parts = string.split(":");
        String key = parts[0];
        if(parts.length >= 2) {
            try {
                count = Integer.parseInt(parts[1]);
            } catch(Exception e) {
                Log.Error(Main.plugin, "Failed to parse particle count from string: " + string + ". Using default of 20.");
            }
        }
        if(parts.length >= 3) {
            try {
                offset = Double.parseDouble(parts[2]);
            } catch(Exception e) {
                Log.Error(Main.plugin, "Failed to parse particle offset from string: " + string + ". Using default of 0.5.");
            }
        }
        if(parts.length >= 4) {
            try {
                extra = Double.parseDouble(parts[3]);
            } catch(Exception e) {
                Log.Error(Main.plugin, "Failed to parse particle extra from string: " + string + ". Using default of 0.02.");
            }
        }
            
        return new Particle(key, count, offset, extra);
    }
    
    /**
     * Spawns this particle at the player's current location.
     * <p>
     * Uses the configured count, offset (applied to x/y/z as spread), and extra
     * parameters.
     * </p>
     *
     * @param player the player whose location is used for spawning
     */
    public void spawn(Player player) {
		player.spawnParticle(this.key, player.getLocation(), this.count, this.offset, this.offset, this.offset, this.extra, null);
    }
    
    /**
     * Spawns this particle at the given world location.
     * <p>
     * Uses the configured count, offset (applied to x/y/z as spread), and extra
     * parameters.
     * </p>
     *
     * @param location the target location for spawning particles
     */
    public void spawn(Location location) {
		location.getWorld().spawnParticle(this.key, location, this.count, this.offset, this.offset, this.offset, this.extra, null);
    }
    
    /**
     * Returns a human-readable description of this particle configuration.
     */
    @Override
    public String toString() {
        // Fields are guaranteed non-null, so print them all unconditionally.
        return "Particle{key=\"" + key + "\", count=" + count + ", offset=" + offset + ", extra=" + extra + "}";
    }
}