package valorless.rarespawns.datamodels;

import org.bukkit.inventory.ItemStack;

/**
 * Represents the inventory data for a rare entity in RareSpawns.
 * Stores item stacks for each equipment slot (main hand, off hand, armor).
 */
public class InventoryData {

	/**
	 * Constructs an empty InventoryData object.
	 */
	public InventoryData() {}
	
	/**
	 * The item in the entity's main hand slot.
	 */
	public ItemStack mainHand;
	/**
	 * The item in the entity's off hand slot.
	 */
	public ItemStack offHand;
	/**
	 * The item in the entity's helmet slot.
	 */
	public ItemStack helmet;
	/**
	 * The item in the entity's chestplate slot.
	 */
	public ItemStack chestplate;
	/**
	 * The item in the entity's leggings slot.
	 */
	public ItemStack leggings;
	/**
	 * The item in the entity's boots slot.
	 */
	public ItemStack boots;
}