package valorless.rarespawns.datamodels;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.TextDisplay;
import org.bukkit.entity.Display.Billboard;
import org.bukkit.entity.Display.Brightness;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import valorless.rarespawns.Lang;
import valorless.rarespawns.Main;
import valorless.rarespawns.builders.EntityCreator;
import valorless.rarespawns.persistentdatacontainer.PDC;
import valorless.rarespawns.utils.ColorUtils;


import java.util.ArrayList;
import java.util.List;

/**
 * Represents a custom nameplate for a rare entity in RareSpawns.
 * Handles creation, updating, and removal of the floating text display above rare entities.
 * Nameplates are updated in real-time to follow the entity and reflect its state (e.g., invisibility, taming).
 */
public class RareEntityNameplate {
	/**
	 * The rare entity this nameplate is attached to.
	 */
	public final LivingEntity rare;
	/**
	 * The TextDisplay entity used for the nameplate.
	 */
    public final TextDisplay nameplate;
    /**
     * The Bukkit runnable task ID for updating the nameplate.
     */
    public Integer runnable;

	/**
	 * Constructs a RareEntityNameplate for the given entity and data.
	 * Spawns a TextDisplay, sets its properties, and schedules updates.
	 *
	 * @param rareEntity The rare entity to attach the nameplate to.
	 * @param data The EntityData containing nameplate settings.
	 */
	public RareEntityNameplate(LivingEntity rareEntity, EntityData data) {
        this.rare = rareEntity;
        Location location = rare.getLocation();
        this.nameplate = (TextDisplay) rare.getWorld().spawnEntity(location, EntityType.TEXT_DISPLAY);
		if(data.name == null) {
			this.nameplate.remove();
			return;
		};
        
		// Tag the nameplate for identification
		PDC.setString(nameplate, "RareEntity-Nameplate", rare.getUniqueId().toString());
		//Tags.Set(Main.plugin, rare.getPersistentDataContainer(), "RareEntity-nameplate", nameplate.getUniqueId().toString(), PersistentDataType.STRING);
		
		// Set a custom name for the nameplate entity
		nameplate.setCustomName("RareEntity-Nameplate");
		
        // Process and set the display text for the nameplate
        List<String> processedName = new ArrayList<>();
        for (String line : data.name) {
        	processedName.add(Lang.parse(line, null));
        }
        nameplate.setText(String.join("\n§r", processedName));

        // Apply nameplate visual settings from EntityData
        if(data.nameTextShadow != null) nameplate.setShadowed(data.nameTextShadow);
        if(data.nameLineWidth != null && data.nameLineWidth != 0) 
        	nameplate.setLineWidth(data.nameLineWidth);
        if(data.nameBillboard != null) nameplate.setBillboard(Billboard.valueOf(data.nameBillboard));
        if(data.nameScale != null) {
        	Vector3f scale = new Vector3f(data.nameScale.floatValue(), data.nameScale.floatValue(), data.nameScale.floatValue()); // Scaling factor
            Transformation transformation = new Transformation(
                new Vector3f(0, 0, 0), // Translation (position offset)
                new AxisAngle4f(),      // Rotation (identity means no rotation)
                scale,                  // Scale
                new AxisAngle4f()       // Left-handed quaternion (identity)
            );
            nameplate.setTransformation(transformation);
        }
    	if(data.nameBackgroundColor != null) nameplate.setBackgroundColor(ColorUtils.getColorFromString(data.nameBackgroundColor));	
    	if(data.nameBackgrond != null && data.nameBackgrond == false) nameplate.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
    	if(data.nameSeeThrough != null) nameplate.setSeeThrough(data.nameSeeThrough);
        if(data.nameViewDistance != null) nameplate.setViewRange(data.nameViewDistance);
        
        // Set interpolation and teleport settings for smooth movement
        nameplate.setInterpolationDelay(5);
        nameplate.setTeleportDuration(1);
        nameplate.setBrightness(new Brightness(15,15));
        
        // Position the nameplate above the entity's eyes, with offset
        Location offset = rare.getEyeLocation().add(data.nameOffset);
        nameplate.teleport(offset);
        
        // Schedule a repeating task to update the nameplate position and state
        runnable = Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.plugin, new Runnable() {
			@Override
			public void run() {   
				if(rare == null || rare.isDead()) {
					remove();
					Bukkit.getScheduler().cancelTask(runnable);
					return;
				}
				// Hide nameplate if entity is invisible
				if(rare.hasPotionEffect(PotionEffectType.INVISIBILITY) && nameplate.getViewRange() != 0) {
					nameplate.setViewRange(0);
				}
				else if(!rare.hasPotionEffect(PotionEffectType.INVISIBILITY) && nameplate.getViewRange() != data.nameViewDistance) {
					nameplate.setViewRange(data.nameViewDistance);
				}

				// If entity is tamed, show its custom name
				if(rare instanceof Tameable tamed && tamed.isTamed()) {
					if(tamed.getCustomName() != null) {
						if(!nameplate.getText().equalsIgnoreCase(tamed.getCustomName())) {
        					nameplate.setText(tamed.getCustomName());
        				}
					}
		        }
				// Update nameplate position to follow entity
		        Location offset = rare.getEyeLocation().add(data.nameOffset);
		        nameplate.teleport(offset);
			}

		}, 1L, 1L);

		// Tag the runnable ID for later removal
		PDC.setInteger(nameplate, "RareEntity-runnable", runnable);
	
    }
    
    /**
     * Removes the nameplate entity and unregisters it from EntityCreator.
     */
    public void remove() {
        nameplate.remove();
    	EntityCreator.nameplates.remove(this);
    }
    
    /**
     * Converts an opacity value (0-255) to a byte for use in ARGB color.
     * @param opacity The opacity value (0-255).
     * @return The scaled byte value (0-127).
     */
    public static byte toByteOpacity(int opacity) {
        if (opacity < 0) opacity = 0;
        if (opacity > 255) opacity = 255;
        return (byte) (opacity / 2); // Scale down to fit 0-127 range
    }
}