package valorless.rarespawns.datamodels;

import valorless.rarespawns.compilers.SoulPowerCompiler;
import valorless.valorlessutils.utils.Utils;


/**
 * Immutable view of a Soul Power's metadata resolved from its annotation.
 * <p>
 * Instances are constructed by reading the {@link valorless.rarespawns.soulpower.SoulPowerInfo}
 * annotation on a compiled Soul Power class returned by {@link SoulPowerCompiler#getPower(String)}.
 * Values are normalized:
 * <ul>
 *   <li>cooldown is clamped to a minimum of 0 seconds</li>
 *   <li>chance is clamped to the 0..100 range</li>
 * </ul>
 * </p>
 */
public class SoulPowerInfo {
	/**
	 * Trigger type for when a Soul Power activates.
	 */
	public final SoulPowerType type;
	/**
	 * Cooldown in seconds between activations. Never negative.
	 */
	public final Double cooldown;
	/**
	 * Percent chance [0..100] to activate when the trigger occurs.
	 */
	public final Double chance;
	/**
	 * If true, apply cooldown even when the activation roll fails.
	 */
	public final Boolean failCooldown;
	
	/**
	 * Builds a SoulPowerInfo by reading the annotation declared on the power with the given ID.
	 *
	 * @param id the registered power ID used to locate the compiled power class
	 */
	public SoulPowerInfo(String id) {
		valorless.rarespawns.soulpower.SoulPowerInfo info = SoulPowerCompiler.getPower(id).getAnnotation(valorless.rarespawns.soulpower.SoulPowerInfo.class);
		this.type = SoulPowerType.get(info.type());
		this.cooldown = Double.valueOf(info.cooldown()) < 0 ? 0 : Double.valueOf(info.cooldown()); 
		this.chance = Utils.Clamp(Double.valueOf(info.chance()), 0.0, 100.0);
		this.failCooldown = Boolean.valueOf(info.failCooldown());
	}
	
	/**
	 * Convenience factory for creating a SoulPowerInfo for the given power ID.
	 *
	 * @param id the registered power ID
	 * @return a new SoulPowerInfo representing the power's metadata
	 */
	public static SoulPowerInfo getAbilityInfo(String id) {
		return new SoulPowerInfo(id);
	}
	
	/**
	 * Supported event trigger types for Soul Powers.
	 */
	public enum SoulPowerType {
		onAttack,
		onDefence,
		onKill,
		onEquip;
		
		/**
		 * Case-insensitive parser for trigger type names.
		 *
		 * @param type the name to parse
		 * @return the matching enum constant, or null if no match
		 */
		public static SoulPowerType get(String type) {
			for (SoulPowerType spt : SoulPowerType.values()) {
				if (spt.name().equalsIgnoreCase(type)) {
					return spt;
				}
			}
			return null;
		}
	}
}