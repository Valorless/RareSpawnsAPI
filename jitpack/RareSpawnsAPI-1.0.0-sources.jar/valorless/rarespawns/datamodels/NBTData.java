package valorless.rarespawns.datamodels;

/**
 * Represents NBT (Named Binary Tag) data for RareSpawns items.
 * Stores the value and type of an NBT tag for use in item metadata.
 */
public class NBTData{
	/**
	 * The value of the NBT tag (e.g., string, integer, boolean, etc.).
	 */
	public String value;
	/**
	 * The type of the NBT tag (e.g., "string", "integer", "boolean").
	 */
	public String type;
	
	/**
	 * Constructs an NBTData object with the specified value and type.
	 * @param value The value of the NBT tag.
	 * @param type The type of the NBT tag.
	 */
	public NBTData(String value, String type) {
		this.value = value;
		this.type = type;
	}
}