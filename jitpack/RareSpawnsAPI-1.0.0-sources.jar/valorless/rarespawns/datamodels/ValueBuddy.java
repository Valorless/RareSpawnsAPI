package valorless.rarespawns.datamodels;

/**
 * Simple generic pair used to keep a primary value and a related companion value together.
 *
 * @param <V> the primary value type
 * @param <B> the companion value type associated with {@code V}
 */
public class ValueBuddy<V,B> {

    /**
     * Primary value of the pair.
     */
    public V value;

    /**
     * Companion value linked to {@link #value}.
     */
    public B buddy;

    /**
     * Creates a new value pair.
     *
     * @param value primary value
     * @param buddy companion value associated with {@code value}
     */
    public ValueBuddy(V value, B buddy) {
        this.value = value;
        this.buddy = buddy;
    }

    /**
     * Factory method; equivalent to {@code new ValueBuddy<>(value, buddy)}.
     *
     * @param <V>   the primary value type
     * @param <B>   the companion value type
     * @param value primary value
     * @param buddy companion value associated with {@code value}
     * @return a new {@code ValueBuddy} containing the given pair
     */
    public static <V,B> ValueBuddy<V,B> of(V value, B buddy) {
    	return new ValueBuddy<>(value, buddy);
    }

    /**
     * Parses a comma-separated string into a {@code ValueBuddy<String, String>}.
     * <p>
     * The input must contain exactly one comma; the text before the comma becomes
     * {@link #value} and the text after becomes {@link #buddy}.  Both parts are
     * trimmed of surrounding whitespace before being stored.
     * <p>
     * <b>Note:</b> because the generic types are erased at runtime this method
     * always returns {@code ValueBuddy<String, String>} regardless of the type
     * parameters declared at the call-site.  The {@code @SuppressWarnings("unchecked")}
     * annotation is present because the raw {@code String} values are cast to
     * {@code V} and {@code B} without a runtime check.
     *
     * @param <V>   the primary value type (must be {@code String} at runtime)
     * @param <B>   the companion value type (must be {@code String} at runtime)
     * @param input a comma-separated string in the format {@code "value, buddy"}
     * @return a new {@code ValueBuddy} from the parsed pair, or {@code null} if
     *         the input does not contain exactly one comma or an exception occurs
     */
    @SuppressWarnings("unchecked")
    public static <V,B> ValueBuddy<V,B> parse(String input) {
        try {
            String[] parts = input.split(",");
            if(parts.length != 2) return null;
            V value = (V) parts[0].trim();
            B buddy = (B) parts[1].trim();
            return new ValueBuddy<>(value, buddy);
        }catch(Exception e) {
            return null;
        }
    }
}
