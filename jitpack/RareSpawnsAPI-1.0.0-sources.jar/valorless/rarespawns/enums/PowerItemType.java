package valorless.rarespawns.enums;

/**
 * Defines the available Power Item types used by the RareSpawns API.
 * This enum is used for categorizing item behavior by a simple, named type.
 */
public enum PowerItemType { 
    /**
     * Unspecified or no-op type.
     */
	NULL,
	/**
	 * Breaker-type power item.
	 */
	BREAKER, 
	/**
	 * Redstone-related power item.
	 */
	REDSTONE, 
	/**
	 * Trowel-type power item.
	 */
	TROWEL;
	
	/**
	 * Returns the PowerItemType matching the given name (case-insensitive).
	 *
	 * @param type the name of the power item type to resolve
	 * @return the matching PowerItemType constant
	 * @throws IllegalArgumentException if the provided name does not match any constant
	 */
	public static PowerItemType get(String type) {
    for (PowerItemType value : PowerItemType.values()) {
        if (value.name().equalsIgnoreCase(type)) {
            return value;
        }
    }
    throw new IllegalArgumentException("Invalid PowerItemType: " + type);
}}