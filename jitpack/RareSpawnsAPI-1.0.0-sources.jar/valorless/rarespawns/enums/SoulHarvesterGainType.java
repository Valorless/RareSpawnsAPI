package valorless.rarespawns.enums;

/**
 * Enumeration of different types of Soul Harvester gain methods.
 * <p>
 * Defines the various categories through which souls can be gained,
 * such as killing, fishing, mining, defence, and building.
 * </p>
 */
public enum SoulHarvesterGainType {
	KILL,
	FISHING,
	MINING,
	DEFENCE,
	BUILDING;
	
	/**
	 * Converts a string representation to the corresponding SoulHarvesterGainType enum value.
	 * <p>
	 * The comparison is case-insensitive. If the input string does not match any enum value,
	 * the method returns null.
	 * </p>
	 *
	 * @param s the string representation of the gain type
	 * @return the corresponding SoulHarvesterGainType enum value, or null if no match is found
	 */
	public static SoulHarvesterGainType fromString(String s) {
		for(SoulHarvesterGainType type : SoulHarvesterGainType.values()) {
			if(type.name().equalsIgnoreCase(s)) {
				return type;
			}
		}
		return null;
	}
	
}
