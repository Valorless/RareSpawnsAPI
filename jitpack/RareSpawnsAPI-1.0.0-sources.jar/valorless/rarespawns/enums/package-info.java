/**
 * Internal enums used by RareSpawns to configure behavior and upgrades.
 */
package valorless.rarespawns.enums;
