package valorless.rarespawns.enums;

/**
 * Enumeration representing different weather conditions.
 */
public enum Weather {

	CLEAR,
	RAIN,
	THUNDER;
	
	/**
	 * Retrieves the Weather enum constant corresponding to the given string, ignoring case.
	 *
	 * @param str The string representation of the weather condition.
	 * @return The matching Weather enum constant, or null if no match is found.
	 */
	public static Weather get(String str) {
		for(Weather weather : Weather.values()) {
			if(weather.name().equalsIgnoreCase(str)) {
				return weather;
			}
		}
		return null;
	}
	
}
