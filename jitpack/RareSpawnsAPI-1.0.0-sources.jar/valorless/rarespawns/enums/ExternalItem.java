package valorless.rarespawns.enums;

/**
 * Enumeration of supported external item plugins.
 */
public enum ExternalItem {
	NULL,
	Nexo,
	ItemsAdder,
	Oraxen;
	
	/**
	 * Retrieves the ExternalItem enum constant matching the provided name.
	 * Supports both enum names and specific namespace prefixes.
	 *
	 * @param name The name or prefix of the external item plugin.
	 * @return The corresponding ExternalItem enum constant, or null if not found.
	 */
	public static ExternalItem get(String name) {
		switch(name.toLowerCase()) {
			case "nexo:":
				return Nexo;
			case "itemsadder:":
				return ItemsAdder;
			case "oraxen:":
				return Oraxen;
		}
		
		for (ExternalItem item : ExternalItem.values()) {
			if (item.name().equalsIgnoreCase(name)) {
				return item;
			}
		}
		return null;
	}
}
