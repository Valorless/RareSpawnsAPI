package valorless.rarespawns.enums;

/**
 * Enumeration of different types of Soul Harvester upgrades.
 * <p>
 * Defines the various categories of upgrades that can be applied to a Soul Harvester,
 * such as attribute modifications, enchantments, power enhancements, model data changes,
 * and item model alterations and more.
 * </p>
 */
public enum SoulHarvesterUpgradeType {
	ATTRIBUTE,
	ENCHANTMENT,
	POWER,
	MODELDATA,
	ITEMMODEL,
	ITEMNAME,
	DISPLAYNAME,
	LORE,
	LOREADD;
	
	/**
	 * Converts a string representation to the corresponding SoulHarvesterUpgradeType enum value.
	 * <p>
	 * The comparison is case-insensitive. If the input string does not match any enum value,
	 * the method returns null.
	 * </p>
	 *
	 * @param s the string representation of the upgrade type
	 * @return the corresponding SoulHarvesterUpgradeType enum value, or null if no match is found
	 */
	public static SoulHarvesterUpgradeType fromString(String s) {
		for(SoulHarvesterUpgradeType type : SoulHarvesterUpgradeType.values()) {
			if(type.name().equalsIgnoreCase(s)) {
				return type;
			}
		}
		return null;
	}
	
}
